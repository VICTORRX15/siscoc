<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Heredar APU — <?= htmlspecialchars((string)($obra['nombre'] ?? '')) ?></h2>
    <p style="color:#475569;margin-bottom:1rem;">
        Elige un APU de cualquiera de tus obras anteriores. Se copiarán sus insumos
        (materiales, mano de obra, equipo) al nuevo APU de esta obra. Podrás editar el código,
        la descripción y los valores antes de guardar.
    </p>

    <div style="margin-bottom:1rem;">
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=apu&action=index&obra_id=<?= (int)$obra['id'] ?>">← Volver a APUs</a>
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=apu&action=crear&obra_id=<?= (int)$obra['id'] ?>">+ Crear desde cero</a>
    </div>

    <?php if (empty($porObra)): ?>
        <div style="padding:1rem;background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;color:#92400e;">
            No tienes APUs en otras obras todavía. Crea uno primero en otra obra, o pulsa "Crear desde cero".
        </div>
    <?php else: ?>
        <?php foreach ($porObra as $obraIdOrigen => $grupo): ?>
            <div style="margin-bottom:1.5rem;">
                <h3 style="background:#1e3a8a;color:#fff;padding:.5rem .8rem;border-radius:6px 6px 0 0;margin:0;font-size:1rem;">
                    🏗️ <?= htmlspecialchars($grupo['obra_nombre']) ?>
                </h3>
                <div class="table-wrap" style="border-radius:0 0 6px 6px;overflow-x:auto;">
                    <table>
                        <thead><tr>
                            <th>Código</th><th>Descripción</th><th>Unidad</th>
                            <th>Materiales</th><th>M. Obra</th><th>Equipo</th>
                            <th>P. Unitario</th><th>Acción</th>
                        </tr></thead>
                        <tbody>
                        <?php foreach ($grupo['apus'] as $a): ?>
                            <tr>
                                <td><?= htmlspecialchars((string)($a['codigo'] ?? '')) ?></td>
                                <td><?= htmlspecialchars((string)($a['descripcion'] ?? '')) ?></td>
                                <td><?= htmlspecialchars((string)($a['unidad'] ?? '')) ?></td>
                                <td><?= number_format((float)$a['materiales'], 2) ?></td>
                                <td><?= number_format((float)$a['mano_obra'], 2) ?></td>
                                <td><?= number_format((float)$a['equipo'], 2) ?></td>
                                <td><strong><?= number_format((float)$a['precio_unitario'], 2) ?></strong></td>
                                <td>
                                    <a class="btn btn-primary" style="padding:.3rem .6rem;font-size:.85rem;"
                                       href="<?= BASE_URL ?>?controller=apu&amp;action=heredarSeleccion&amp;apu_origen_id=<?= (int)$a['id'] ?>&amp;obra_id=<?= (int)$obra['id'] ?>">
                                        Heredar este
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>