<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2><?= isset($apu['id']) ? 'Editar' : 'Nuevo' ?> Análisis de Precio Unitario (APU)</h2>

    <form method="post" id="form-apu" style="max-width:1000px;background:#fff;padding:1.5rem;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.05);"
          action="<?= BASE_URL ?>?controller=apu&action=<?= isset($apu['id']) ? 'editar&id='.(int)$apu['id'] : 'crear' ?>&obra_id=<?= (int)$obra['id'] ?>">

        <!-- CABECERA DEL APU -->
<div style="display:grid;grid-template-columns:80px 1fr 100px 100px 120px;gap:.8rem;margin-bottom:1.5rem;background:#f8fafc;padding:1rem;border-radius:8px;">
    <label>Item<br><input name="apu_item" value="<?= htmlspecialchars($apu['item'] ?? '') ?>" placeholder="1.1" style="width:100%;padding:.5rem;"></label>
    
    <!-- 👇 CAMBIADO A apu_descripcion -->
    <label>Descripción<br><input name="apu_descripcion" value="<?= htmlspecialchars($apu['descripcion'] ?? '') ?>" required placeholder="CERCO DE PROTECCIÓN..." style="width:100%;padding:.5rem;"></label>
    
    <label>Código<br><input name="codigo" value="<?= htmlspecialchars($apu['codigo'] ?? '') ?>" required placeholder="CP010" style="width:100%;padding:.5rem;"></label>
    
    <!-- 👇 CAMBIADO A apu_unidad -->
    <label>Unidad<br><input name="apu_unidad" value="<?= htmlspecialchars($apu['unidad'] ?? '') ?>" required placeholder="m2" style="width:100%;padding:.5rem;"></label>
    
    <label>Costo [Bs] (Total)<br>
        <input name="precio_unitario" id="costo_total" readonly value="<?= htmlspecialchars((string)($apu['precio_unitario'] ?? 0)) ?>"
               style="width:100%;padding:.5rem;background:#dcfce7;font-weight:bold;border:1px solid #86efac;color:#166534;text-align:right;">
    </label>
</div>
        <!-- TABLA DE INSUMOS -->
        <table style="width:100%;border-collapse:collapse;font-size:.9rem;" id="tabla-insumos">
            <thead>
                <tr style="background:#0f172a;color:#fff;">
                    <th style="width:120px;text-align:left;padding:.5rem;">Categoría</th>
                    <th style="text-align:left;padding:.5rem;">Descripción</th>
                    <th style="width:60px;padding:.5rem;">Unidad</th>
                    <th style="width:80px;padding:.5rem;">Rend.</th>
                    <th style="width:80px;padding:.5rem;">P.U. (Bs)</th>
                    <th style="width:100px;padding:.5rem;">Total (Bs)</th>
                    <th style="width:40px;padding:.5rem;"></th>
                </tr>
            </thead>
            <tbody id="cuerpo-insumos">
                <!-- Aquí se insertan las filas con JS -->
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="7" style="padding-top:1rem;">
                        <button type="button" class="btn btn-outline" onclick="agregarFila('materiales')">+ Material</button>
                        <button type="button" class="btn btn-outline" onclick="agregarFila('mano_obra')">+ Mano de Obra</button>
                        <button type="button" class="btn btn-outline" onclick="agregarFila('herramientas')">+ Herramienta</button>
                    </td>
                </tr>
            </tfoot>
        </table>

        <p style="margin-top:2rem;border-top:1px solid #e2e8f0;padding-top:1rem;">
            <button class="btn btn-primary" type="submit">Guardar APU</button>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=apu&action=index&obra_id=<?= (int)$obra['id'] ?>">Cancelar</a>
        </p>
    </form>
</div>

<script>
// Cargar datos si es edición
const detallesGuardados = <?= json_encode($apu['detalles'] ?? []) ?>;

function crearFilaHTML(tipo, desc, uni, rend, pu) {
    const colores = {
        'materiales': '#dbeafe',
        'mano_obra': '#dcfce7',
        'herramientas': '#fef3c7'
    };
    const color = colores[tipo] || '#fff';

    return `
        <tr style="border-bottom:1px solid #e2e8f0;">
            <td style="padding:.3rem;">
                <select name="tipo[]" onchange="cambiarColor(this)" style="width:100%;padding:.4rem;background:${color};border:1px solid #cbd5e1;border-radius:4px;">
                    <option value="materiales" ${tipo==='materiales'?'selected':''}>Material</option>
                    <option value="mano_obra" ${tipo==='mano_obra'?'selected':''}>M. Obra</option>
                    <option value="herramientas" ${tipo==='herramientas'?'selected':''}>Herram.</option>
                </select>
            </td>
            <td style="padding:.3rem;"><input type="text" name="descripcion[]" value="${desc}" required style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;"></td>
            <td style="padding:.3rem;"><input type="text" name="unidad_item[]" value="${uni}" required style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:center;"></td>
            <td style="padding:.3rem;"><input type="number" step="0.001" name="rendimiento[]" value="${rend}" required class="input-rend" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><input type="number" step="0.01" name="pu[]" value="${pu}" required class="input-pu" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><input type="text" readonly class="fila-total" value="0.00" style="width:100%;padding:.4rem;background:#f0fdf4;color:#166534;font-weight:bold;border:1px solid #bbf7d0;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><button type="button" class="btn btn-danger" style="padding:.3rem .5rem;" onclick="this.closest('tr').remove(); calcularTotales();">X</button></td>
        </tr>
    `;
}

function cambiarColor(select) {
    const colores = { 'materiales': '#dbeafe', 'mano_obra': '#dcfce7', 'herramientas': '#fef3c7' };
    select.style.background = colores[select.value] || '#fff';
}

function agregarFila(tipo, desc='', uni='', rend=1, pu=0) {
    const tbody = document.getElementById('cuerpo-insumos');
    tbody.insertAdjacentHTML('beforeend', crearFilaHTML(tipo, desc, uni, rend, pu));
    
    // Escuchar cambios en los nuevos inputs
    const nuevaFila = tbody.lastElementChild;
    nuevaFila.querySelector('.input-rend').addEventListener('input', calcularTotales);
    nuevaFila.querySelector('.input-pu').addEventListener('input', calcularTotales);
    
    calcularTotales();
}

// Función principal de cálculo
function calcularTotales() {
    let granTotal = 0;
    const filas = document.querySelectorAll('#cuerpo-insumos tr');
    
    filas.forEach(fila => {
        // Obtenemos los valores, si están vacíos valen 0
        const rend = parseFloat(fila.querySelector('.input-rend').value) || 0;
        const pu = parseFloat(fila.querySelector('.input-pu').value) || 0;
        
        // Multiplicación (Rendimiento x Precio Unitario)
        const totalFila = rend * pu;
        
        // Mostrar en la celda
        fila.querySelector('.fila-total').value = totalFila.toFixed(2);
        
        // Sumar al total general
        granTotal += totalFila;
    });

    // Actualizar el input grande verde de arriba
    document.getElementById('costo_total').value = granTotal.toFixed(2);
}

// Cargar filas si es que estamos editando
if (detallesGuardados.length > 0) {
    detallesGuardados.forEach(d => {
        agregarFila(d.tipo, d.descripcion, d.unidad, d.rendimiento, d.precio_unitario);
    });
} else {
    // Si es nuevo, poner una fila vacía por defecto
    agregarFila('materiales');
}

// Desactivar filas vacías al enviar para que no den error en PHP
document.getElementById('form-apu').addEventListener('submit', function(e) {
    document.querySelectorAll('#cuerpo-insumos tr').forEach(fila => {
        const desc = fila.querySelector('input[name="descripcion[]"]').value.trim();
        const pu = fila.querySelector('.input-pu').value;
        if (desc === '' || pu === '') {
            fila.querySelectorAll('input, select').forEach(el => el.disabled = true);
        }
    });
});
</script>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>