<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>APUs — <?= htmlspecialchars((string)($obra['nombre'] ?? '')) ?></h2>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;">
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=apu&action=crear&obra_id=<?= (int)$obra['id'] ?>">+ Nuevo APU</a>
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=ver&id=<?= (int)$obra['id'] ?>">← Volver a la obra</a>
    </div>

    <div class="table-wrap" style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>Item</th><th>Código</th><th>Descripción</th>
                    <th>Unidad</th><th>Costo Total (Bs.)</th><th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($apus as $a): ?>
                <tr>
                    <td><?= htmlspecialchars((string)($a['item'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['codigo'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['descripcion'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['unidad'] ?? '')) ?></td>
                    <td><strong><?= number_format((float)$a['precio_unitario'], 2) ?></strong></td>
                    <td style="white-space:nowrap;">
                        <a class="btn btn-outline" style="padding:.3rem .6rem;font-size:.85rem;"
                           href="<?= BASE_URL ?>?controller=apu&action=editar&id=<?= (int)$a['id'] ?>&obra_id=<?= (int)$obra['id'] ?>">Editar / Ver</a>
                        <a class="btn btn-danger" style="padding:.3rem .6rem;font-size:.85rem;"
                           onclick="return confirm('¿Eliminar APU y todos sus insumos?')"
                           href="<?= BASE_URL ?>?controller=apu&action=eliminar&id=<?= (int)$a['id'] ?>&obra_id=<?= (int)$obra['id'] ?>">Borrar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($apus)): ?><tr><td colspan="6" style="text-align:center;">Sin APUs registrados.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>