<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>APU: <code><?= htmlspecialchars($apu['codigo']) ?></code></h2>
    <div class="card mb-2">
        <p><strong>Descripción:</strong> <?= htmlspecialchars($apu['descripcion']) ?></p>
        <p><strong>Unidad:</strong> <?= htmlspecialchars($apu['unidad']) ?></p>
        <p><strong>Precio unitario:</strong> <?= number_format((float)$apu['precio_unit'], 4) ?></p>
    </div>

    <h3>Detalle del APU</h3>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Tipo</th><th>Descripción</th><th>Unidad</th><th>Cantidad</th><th>Precio Unit.</th><th>Subtotal</th></tr></thead>
            <tbody>
            <?php foreach ($detalles as $d): ?>
                <tr>
                    <td><?= htmlspecialchars($d['tipo']) ?></td>
                    <td><?= htmlspecialchars($d['descripcion']) ?></td>
                    <td><?= htmlspecialchars($d['unidad']) ?></td>
                    <td><?= number_format((float)$d['cantidad'], 4) ?></td>
                    <td><?= number_format((float)$d['precio_unit'], 4) ?></td>
                    <td><?= number_format((float)$d['subtotal'], 4) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($detalles)): ?>
                <tr><td colspan="6" class="text-center muted">Sin insumos aún.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="mt-2"><a class="btn btn-outline" href="<?= BASE_URL ?>?controller=apu&action=index">← Volver</a></p>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>