<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Cómputos Métricos — <?= htmlspecialchars((string)($obra['nombre'] ?? '')) ?></h2>

    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;">
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=computo&action=crear&obra_id=<?= (int)$obra['id'] ?>">+ Nuevo Cómputo</a>
        <a class="btn btn-success" href="<?= BASE_URL ?>?controller=computo&action=exportar&obra_id=<?= (int)$obra['id'] ?>">📥 Exportar Excel</a>
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=ver&id=<?= (int)$obra['id'] ?>">← Volver</a>
    </div>

    <?php
    // Agrupar por item
    $porItem = [];
    foreach ($computos as $c) {
        $key = ($c['item'] ?? '') === '' ? '(sin item)' : $c['item'];
        $porItem[$key][] = $c;
    }
    $totalGeneral = 0;
    ?>

    <?php foreach ($porItem as $item => $lineas): ?>
        <?php
        $totalItem = 0;
        foreach ($lineas as $l) { $totalItem += (float)$l['parcial']; }
        $totalGeneral += $totalItem;
        ?>
        <div style="margin-bottom:1.5rem;">
            <h3 style="background:#0f172a;color:#fff;padding:.5rem .8rem;border-radius:6px 6px 0 0;margin:0;">
                Ítem <?= htmlspecialchars((string)$item) ?>
            </h3>
            <div class="table-wrap" style="overflow-x:auto;border-radius:0 0 6px 6px;">
                <table>
                    <thead><tr>
                        <th>Descripción General</th><th>Unidad</th>
                        <th>Cantidad Total</th><th>P. Unit (APU)</th><th>Subtotal</th><th>Acciones</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($lineas as $c): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($c['descripcion']) ?></strong>
                                <?php if (!empty($c['detalles'])): ?>
                                    <ul style="margin: .3rem 0 0 1rem; font-size: .8rem; color: #64748b; padding: 0;">
                                        <?php foreach ($c['detalles'] as $det): ?>
                                            <li>
                                                <?= htmlspecialchars((string)($det['descripcion_linea'] ?: 'Línea de cálculo')) ?>: 
                                                <?= number_format((float)$det['cantidad'], 3) ?> <?= htmlspecialchars((string)$c['unidad']) ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars((string)$c['unidad']) ?></td>
                            <td><?= number_format((float)$c['cantidad'], 3) ?></td>
                            <td><?= number_format((float)$c['precio_unitario'], 2) ?></td>
                            <td><?= number_format((float)$c['parcial'], 2) ?></td>
                            <td style="white-space:nowrap;">
                                <a class="btn btn-outline" style="padding:.3rem .6rem;font-size:.85rem;"
                                   href="<?= BASE_URL ?>?controller=computo&action=editar&id=<?= (int)$c['id'] ?>&obra_id=<?= (int)$obra['id'] ?>">Editar</a>
                                <a class="btn btn-danger" style="padding:.3rem .6rem;font-size:.85rem;"
                                   onclick="return confirm('¿Eliminar cómputo?')"
                                   href="<?= BASE_URL ?>?controller=computo&action=eliminar&id=<?= (int)$c['id'] ?>&obra_id=<?= (int)$obra['id'] ?>">Borrar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <tfoot><tr style="background:#e2e8f0;font-weight:bold;">
                        <td colspan="4" style="text-align:right;">TOTAL ÍTEM <?= htmlspecialchars((string)$item) ?></td>
                        <td colspan="2"><?= number_format($totalItem, 2) ?> Bs.</td>
                    </tr></tfoot>
                </table>
            </div>
        </div>
    <?php endforeach; ?>

    <?php if (empty($porItem)): ?>
        <p style="text-align:center;color:#64748b;">Sin cómputos registrados.</p>
    <?php endif; ?>

    <div style="background:#0f172a;color:#fff;padding:.8rem 1rem;border-radius:8px;
                display:flex;justify-content:space-between;font-weight:bold;font-size:1.1rem;">
        <span>TOTAL GENERAL</span>
        <span><?= number_format($totalGeneral, 2) ?> Bs.</span>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>