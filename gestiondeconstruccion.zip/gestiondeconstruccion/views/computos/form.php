<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2><?= isset($computo['id']) ? 'Editar' : 'Nuevo' ?> Cómputo — <?= htmlspecialchars((string)($obra['nombre'] ?? '')) ?></h2>

    <form method="post" id="form-computo" style="background:#fff;padding:1.5rem;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.05);"
          action="<?= BASE_URL ?>?controller=computo&action=<?= isset($computo['id']) ? 'editar&id='.(int)$computo['id'] : 'crear' ?>&obra_id=<?= (int)$obra['id'] ?>">

        <!-- CABECERA DEL CÓMPUTO -->
        <div style="display:grid;grid-template-columns:80px 1fr 120px;gap:.8rem;margin-bottom:1rem;">
            <label>Item<br><input name="item" value="<?= htmlspecialchars($computo['item'] ?? '') ?>" placeholder="1.1" style="width:100%;padding:.5rem;"></label>
            <label>Descripción General<br><input name="descripcion" required value="<?= htmlspecialchars($computo['descripcion'] ?? '') ?>" placeholder="Muro de ladrillo..." style="width:100%;padding:.5rem;"></label>
            <label>Unidad<br><input name="unidad" required value="<?= htmlspecialchars($computo['unidad'] ?? '') ?>" placeholder="m2, m3" style="width:100%;padding:.5rem;"></label>
        </div>
        
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.8rem;margin-bottom:1.5rem;background:#f8fafc;padding:1rem;border-radius:8px;">
            <label>APU (Precio se hereda)<br>
                <select name="apu_id" id="apu_id" required style="width:100%;padding:.5rem;">
                    <option value="">— Selecciona APU —</option>
                    <?php foreach ($apus as $a): ?>
                        <option value="<?= (int)$a['id'] ?>" data-precio="<?= (float)$a['precio_unitario'] ?>" <?= ((int)($computo['apu_id'] ?? 0) === (int)$a['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($a['codigo'].' - '.$a['descripcion']) ?> (<?= number_format((float)$a['precio_unitario'], 2) ?> Bs.)
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Tipo de cálculo (Global)<br>
                <select name="tipo_calculo" id="tipo_calculo" style="width:100%;padding:.5rem;">
                    <option value="unidad" <?= (($computo['tipo_calculo'] ?? '') === 'unidad') ? 'selected' : '' ?>>Unidad (Solo N°)</option>
                    <option value="longitud" <?= (($computo['tipo_calculo'] ?? '') === 'longitud') ? 'selected' : '' ?>>Longitud (L)</option>
                    <option value="area" <?= (($computo['tipo_calculo'] ?? '') === 'area') ? 'selected' : '' ?>>Área (L × A)</option>
                    <option value="volumen" <?= (($computo['tipo_calculo'] ?? '') === 'volumen') ? 'selected' : '' ?>>Volumen (L × A × H)</option>
                </select>
            </label>
            <label>Observación General<br><input name="observacion" value="<?= htmlspecialchars($computo['observacion'] ?? '') ?>" style="width:100%;padding:.5rem;"></label>
        </div>

        <!-- TABLA DE DETALLES (LÍNEAS DE CÁLCULO) -->
        <h3 style="font-size:1rem;margin-bottom:.5rem;">Líneas de Cálculo</h3>
        <div style="overflow-x:auto;">
            <table style="width:100%;border-collapse:collapse;font-size:.9rem;" id="tabla-lineas">
                <thead>
                    <tr style="background:#0f172a;color:#fff;">
                        <th style="text-align:left;padding:.5rem;">Descripción de la línea (opcional)</th>
                        <th style="width:70px;padding:.5rem;">N° Veces</th>
                        <th style="width:70px;padding:.5rem;">Factor</th>
                        <th style="width:70px;padding:.5rem;">Largo</th>
                        <th style="width:70px;padding:.5rem;">Ancho</th>
                        <th style="width:70px;padding:.5rem;">Alto</th>
                        <th style="width:90px;padding:.5rem;">Parcial</th>
                        <th style="width:40px;padding:.5rem;"></th>
                    </tr>
                </thead>
                <tbody id="cuerpo-lineas">
                    <!-- Se llena con JS -->
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="8" style="padding-top:1rem;">
                            <button type="button" class="btn btn-outline" onclick="agregarLinea()">+ Añadir Línea</button>
                        </td>
                    </tr>
                    <tr style="border-top:2px solid #0f172a;">
                        <td colspan="6" style="text-align:right;padding:.8rem;font-weight:bold;">CANTIDAD TOTAL:</td>
                        <td style="text-align:right;padding:.8rem;font-weight:bold;background:#f1f5f9;font-size:1.1rem;" id="total_cantidad">0.000</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="6" style="text-align:right;padding:.8rem;font-weight:bold;">SUBTOTAL (Bs):</td>
                        <td style="text-align:right;padding:.8rem;font-weight:bold;background:#dcfce7;color:#166534;font-size:1.1rem;" id="total_subtotal">0.00</td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <p style="margin-top:1.5rem;">
            <button class="btn btn-primary" type="submit">Guardar Cómputo</button>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=computo&action=index&obra_id=<?= (int)$obra['id'] ?>">Cancelar</a>
        </p>
    </form>
</div>

<script>
const detallesGuardados = <?= json_encode($computo['detalles'] ?? []) ?>;

function crearFilaHTML(desc, n, f, l, a, h) {
    return `
        <tr style="border-bottom:1px solid #e2e8f0;">
            <td style="padding:.3rem;"><input type="text" name="descripcion_linea[]" value="${desc}" placeholder="Ej: Muro frontal" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;"></td>
            <td style="padding:.3rem;"><input type="number" step="0.01" name="nro_veces[]" class="in-n" value="${n}" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><input type="number" step="0.001" name="factor_forma[]" class="in-f" value="${f}" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><input type="number" step="0.001" name="largo[]" class="in-l" value="${l}" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><input type="number" step="0.001" name="ancho[]" class="in-a" value="${a}" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><input type="number" step="0.001" name="alto[]" class="in-h" value="${h}" style="width:100%;padding:.4rem;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><input type="text" readonly class="fila-parcial" value="0.00" style="width:100%;padding:.4rem;background:#f8fafc;border:1px solid #cbd5e1;border-radius:4px;text-align:right;"></td>
            <td style="padding:.3rem;"><button type="button" class="btn btn-danger" style="padding:.3rem .5rem;" onclick="this.closest('tr').remove(); calcularTodo();">X</button></td>
        </tr>
    `;
}

function agregarLinea(desc='', n=1, f=1, l=0, a=0, h=0) {
    const tbody = document.getElementById('cuerpo-lineas');
    tbody.insertAdjacentHTML('beforeend', crearFilaHTML(desc, n, f, l, a, h));
    
    // Escuchar inputs
    const fila = tbody.lastElementChild;
    fila.querySelectorAll('input').forEach(inp => inp.addEventListener('input', calcularTodo));
    
    calcularTodo();
}

function calcularTodo() {
    let cantTotal = 0;
    const tipo = document.getElementById('tipo_calculo').value;
    const selApu = document.getElementById('apu_id');
    const precioUnitario = parseFloat(selApu.options[selApu.selectedIndex]?.dataset?.precio || 0) || 0;
    
    document.querySelectorAll('#cuerpo-lineas tr').forEach(fila => {
        const n = parseFloat(fila.querySelector('.in-n').value) || 1;
        const f = parseFloat(fila.querySelector('.in-f').value) || 1;
        const l = parseFloat(fila.querySelector('.in-l').value) || 0;
        const a = parseFloat(fila.querySelector('.in-a').value) || 0;
        const h = parseFloat(fila.querySelector('.in-h').value) || 0;
        
        let base = 1;
        if (tipo === 'area') base = l * a;
        if (tipo === 'volumen') base = l * a * h;
        if (tipo === 'longitud') base = l;
        
        const cant = base * n * f;
        fila.querySelector('.fila-parcial').value = cant.toFixed(3);
        cantTotal += cant;
    });
    
    document.getElementById('total_cantidad').textContent = cantTotal.toFixed(3);
    document.getElementById('total_subtotal').textContent = (cantTotal * precioUnitario).toFixed(2);
}

// Cambiar tipo o APU recalcula
document.getElementById('tipo_calculo').addEventListener('change', calcularTodo);
document.getElementById('apu_id').addEventListener('change', calcularTodo);

// Cargar si es edición
if (detallesGuardados.length > 0) {
    detallesGuardados.forEach(d => {
        agregarLinea(d.descripcion_linea, d.nro_veces, d.factor_forma, d.largo, d.ancho, d.alto);
    });
} else {
    agregarLinea(); // Empezar con una fila vacía
}
</script>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>