<?php
if (!defined('BASE_URL')) { http_response_code(500); die('BASE_URL no definida'); }
$userNombre = class_exists('Auth') ? Auth::nombre() : 'Invitado';
$userRol    = class_exists('Auth') ? Auth::rol()    : 'usuario';
$esAdmin    = class_exists('Auth') && Auth::esAdmin();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de SISCOC</title>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>css/style.css">
</head>
<body>
<header class="topbar">
    <div class="container topbar-inner">
        <a class="brand" href="<?= BASE_URL ?>?controller=dashboard&action=index">
            <img src="<?= ASSETS_URL ?>img/logo_sistema.png" alt="" style="height:28px;vertical-align:middle;margin-right:.4rem;">
            Gestión SISCOC
        </a>
        <nav>
        <?php if ($esAdmin): ?>
            <a href="<?= BASE_URL ?>?controller=dashboard&action=index">Dashboard</a>
            <a href="<?= BASE_URL ?>?controller=user&action=index">Usuarios</a>
            <a href="<?= BASE_URL ?>?controller=token&action=index">Solicitudes Token</a>
            <a href="<?= BASE_URL ?>?controller=reporte&action=index">Reportes</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>?controller=dashboard&action=index">Dashboard</a>
            <a href="<?= BASE_URL ?>?controller=obra&action=index">Mis Obras</a>
        <?php endif; ?>
            <span class="user">👤 <?= htmlspecialchars($userNombre) ?> (<?= htmlspecialchars($userRol) ?>)</span>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=auth&action=logout">Salir</a>
        </nav>
    </div>
</header>
<main class="container">