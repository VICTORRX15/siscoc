</main>
<footer class="footer">
    <div class="container">
        &copy; <?= date('Y') ?> SISCOC-Victor Condori 
    </div>
</footer>
</body>
</html>