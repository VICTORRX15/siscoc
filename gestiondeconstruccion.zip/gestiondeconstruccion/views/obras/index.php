<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Mis Obras</h2>

    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;">
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=obra&action=crear">+ Nueva Obra</a>
        <a class="btn btn-success" href="<?= BASE_URL ?>?controller=export&action=obras">📥 Exportar Excel</a>
    </div>

    <div class="table-wrap" style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>ID</th><th>Nombre</th><th>Ubicación</th><th>Cliente</th>
                    <th>Presupuesto</th><th>Límite</th><th>Estado</th><th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($obras as $o): ?>
                <tr>
                    <td><?= (int)$o['id'] ?></td>
                    <td><?= htmlspecialchars($o['nombre']) ?></td>
                    <td><?= htmlspecialchars($o['ubicacion'] ?? '') ?></td>
                    <td><?= htmlspecialchars($o['cliente'] ?? '') ?></td>
                    <td><?= number_format((float)$o['presupuesto'], 2) ?></td>
                    <td>
                        <?php $lim = (float)($o['presupuesto_limite'] ?? 0); ?>
                        <?= $lim > 0 ? number_format($lim, 2) : '<em>Sin límite</em>' ?>
                    </td>
                    <td><?= htmlspecialchars($o['estado']) ?></td>
                    <td style="white-space:nowrap;">
                        <a class="btn btn-outline" style="padding:.3rem .6rem;font-size:.85rem;"
                           href="<?= BASE_URL ?>?controller=obra&action=ver&id=<?= (int)$o['id'] ?>">Ver</a>
                        <a class="btn btn-outline" style="padding:.3rem .6rem;font-size:.85rem;"
                           href="<?= BASE_URL ?>?controller=obra&action=editar&id=<?= (int)$o['id'] ?>">Editar</a>
                        <a class="btn btn-danger" style="padding:.3rem .6rem;font-size:.85rem;"
                           onclick="return confirm('¿Eliminar la obra «<?= htmlspecialchars($o['nombre'], ENT_QUOTES) ?>»? Se borrarán sus APUs, cómputos, presupuesto y cronograma.')"
                           href="<?= BASE_URL ?>?controller=obra&action=eliminar&id=<?= (int)$o['id'] ?>">Borrar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($obras)): ?>
                <tr><td colspan="8" style="text-align:center;padding:1.5rem;color:#64748b;">Sin obras registradas.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>