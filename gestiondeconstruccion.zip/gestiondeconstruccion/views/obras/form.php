<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<?php $esEdicion = isset($obra['id']); ?>
<div class="container">
    <h2><?= $esEdicion ? 'Editar Obra' : 'Nueva Obra' ?></h2>

    <?php if (!empty($error)): ?>
        <div style="padding:.8rem;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;color:#991b1b;margin-bottom:1rem;">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="post" style="max-width:700px;background:#fff;padding:1.2rem;border-radius:10px;"
          action="<?= BASE_URL ?>?controller=obra&action=<?= $esEdicion ? 'editar&id='.(int)$obra['id'] : 'crear' ?>">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem;">
            <label>Nombre *<br>
                <input name="nombre" required value="<?= htmlspecialchars($obra['nombre'] ?? '') ?>" style="width:100%;padding:.5rem;"></label>
            <label>Cliente<br>
                <input name="cliente" value="<?= htmlspecialchars($obra['cliente'] ?? '') ?>" style="width:100%;padding:.5rem;"></label>
            <label>Ubicación<br>
                <input name="ubicacion" value="<?= htmlspecialchars($obra['ubicacion'] ?? '') ?>" style="width:100%;padding:.5rem;"></label>
            <label>Estado<br>
                <select name="estado" style="width:100%;padding:.5rem;">
                    <?php foreach (['planificacion'=>'Planificación','ejecucion'=>'Ejecución','finalizada'=>'Finalizada'] as $k=>$v): ?>
                        <option value="<?= $k ?>" <?= (($obra['estado'] ?? 'planificacion') === $k) ? 'selected' : '' ?>><?= $v ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Presupuesto (Bs.)<br>
                <input name="presupuesto" type="number" step="0.01" value="<?= htmlspecialchars((string)($obra['presupuesto'] ?? 0)) ?>" style="width:100%;padding:.5rem;"></label>
            <label>Presupuesto límite (Bs.)<br>
                <input name="presupuesto_limite" type="number" step="0.01" value="<?= htmlspecialchars((string)($obra['presupuesto_limite'] ?? 0)) ?>" style="width:100%;padding:.5rem;">
                <small style="color:#64748b;">0 = sin límite</small></label>
        </div>
        <p style="margin-top:1rem;">
            <button class="btn btn-primary" type="submit">Guardar</button>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=index">Cancelar</a>
        </p>
    </form>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>