<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2><?= htmlspecialchars($obra['nombre']) ?></h2>

    <div style="background:#fff;padding:1rem;border-radius:10px;margin-bottom:1rem;">
        <p><strong>Cliente:</strong> <?= htmlspecialchars($obra['cliente'] ?? '—') ?></p>
        <p><strong>Ubicación:</strong> <?= htmlspecialchars($obra['ubicacion'] ?? '—') ?></p>
        <p><strong>Estado:</strong> <?= htmlspecialchars($obra['estado']) ?></p>
        <p><strong>Presupuesto:</strong> <?= number_format((float)$obra['presupuesto'], 2) ?> Bs.</p>
        <p><strong>Presupuesto límite:</strong>
            <?php $lim = (float)($obra['presupuesto_limite'] ?? 0); ?>
            <?= $lim > 0 ? number_format($lim, 2).' Bs.' : 'Sin límite' ?>
        </p>
    </div>

    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin:1rem 0;">
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=apu&action=index&obra_id=<?= (int)$obra['id'] ?>">📐 APUs</a>
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=computo&action=index&obra_id=<?= (int)$obra['id'] ?>">📊 Cómputos</a>
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=presupuesto&action=index&obra_id=<?= (int)$obra['id'] ?>">💰 Presupuesto</a>
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=cronograma&action=index&obra_id=<?= (int)$obra['id'] ?>">📅 Cronograma</a>
    </div>

    <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=editar&id=<?= (int)$obra['id'] ?>">Editar obra</a>
        <a class="btn btn-danger" onclick="return confirm('¿Eliminar esta obra y todos sus datos?')"
           href="<?= BASE_URL ?>?controller=obra&action=eliminar&id=<?= (int)$obra['id'] ?>">Borrar obra</a>
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=index">← Volver</a>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>