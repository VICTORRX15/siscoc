<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Nuevo Presupuesto — <?= htmlspecialchars($obra['nombre']) ?></h2>
    <form method="post" style="max-width:600px;">
        <p><label>Nombre<br><input name="nombre" required style="width:100%;padding:.5rem;"></label></p>
        <p><label>Total<br><input name="total" type="number" step="0.01" value="0" style="width:100%;padding:.5rem;"></label></p>
        <button class="btn btn-primary" type="submit">Guardar</button>
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=presupuesto&action=index&obra_id=<?= (int)$obra['id'] ?>">Cancelar</a>
    </form>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>