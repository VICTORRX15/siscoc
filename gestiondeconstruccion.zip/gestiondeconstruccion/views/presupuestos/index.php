<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Presupuesto — <?= htmlspecialchars((string)($obra['nombre'] ?? '')) ?></h2>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;">
        <a class="btn btn-success" href="<?= BASE_URL ?>?controller=presupuesto&action=exportar&obra_id=<?= (int)$obra['id'] ?>">📥 Exportar Excel</a>
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=ver&id=<?= (int)$obra['id'] ?>">← Volver</a>
    </div>

    <!-- RESUMEN -->
    <div class="table-wrap" style="margin-bottom:1rem;">
        <table>
            <tr><th style="text-align:left;">Presupuesto límite</th>
                <td style="text-align:right;"><?= $detalle['limite'] > 0 ? number_format($detalle['limite'], 2).' Bs.' : '<em>Sin límite</em>' ?></td></tr>
            <tr><th style="text-align:left;">Total APUs (referencia)</th>
                <td style="text-align:right;"><?= number_format($detalle['apus_total'], 2) ?> Bs.</td></tr>
            <tr><th style="text-align:left;">Total cómputos métricos</th>
                <td style="text-align:right;"><strong><?= number_format($detalle['computos_total'], 2) ?> Bs.</strong></td></tr>
            <?php if ($detalle['limite'] > 0): ?>
            <tr><th style="text-align:left;">Disponible</th>
                <td style="text-align:right;"><?= number_format($detalle['disponible'], 2) ?> Bs.</td></tr>
            <?php endif; ?>
            <tr><th style="text-align:left;">Avance ponderado (cronograma)</th>
                <td style="text-align:right;"><?= $detalle['avance_pct'] ?> %</td></tr>
            <tr><th style="text-align:left;">Estado</th>
                <td style="text-align:right;">
                    <?= $detalle['excedido']
                        ? '<span style="color:#dc2626;font-weight:bold;">EXCEDIDO</span>'
                        : ($detalle['limite']>0 ? '<span style="color:#16a34a;font-weight:bold;">Dentro del límite</span>' : '<em>Sin límite</em>') ?>
                </td></tr>
        </table>
    </div>

    <!-- RESUMEN POR ÍTEM -->
    <h3>Resumen por ítem</h3>
    <div class="table-wrap" style="margin-bottom:1rem;">
        <table>
            <thead><tr><th>Item</th><th style="text-align:right;">Líneas</th><th style="text-align:right;">Cantidad total</th><th style="text-align:right;">Subtotal (Bs.)</th><th style="text-align:right;">% del total</th></tr></thead>
            <tbody>
            <?php foreach ($detalle['por_item'] as $r):
                $pct = $detalle['computos_total'] > 0 ? ((float)$r['total'] / $detalle['computos_total']) * 100 : 0; ?>
                <tr>
                    <td><?= htmlspecialchars((string)($r['item'] ?? '(sin item)')) ?></td>
                    <td style="text-align:right;"><?= (int)$r['lineas'] ?></td>
                    <td style="text-align:right;"><?= number_format((float)$r['cantidad'], 3) ?></td>
                    <td style="text-align:right;"><?= number_format((float)$r['total'], 2) ?></td>
                    <td style="text-align:right;"><?= number_format($pct, 1) ?> %</td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($detalle['por_item'])): ?><tr><td colspan="5" style="text-align:center;">Sin cómputos.</td></tr><?php endif; ?>
            </tbody>
            <tfoot><tr class="total"><th colspan="3" style="text-align:right;">TOTAL</th><th style="text-align:right;"><?= number_format($detalle['computos_total'], 2) ?></th><th>100 %</th></tr></tfoot>
        </table>
    </div>

    <!-- APUs DETALLADOS -->
        <!-- APUs DETALLADOS -->
    <h3>APUs de la obra</h3>
    <div class="table-wrap" style="margin-bottom:1rem;overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Código</th>
                    <th>Descripción</th>
                    <th>Unidad</th>
                    <th style="text-align:right;">Materiales</th>
                    <th style="text-align:right;">M. Obra</th>
                    <th style="text-align:right;">Equipo</th>
                    <th style="text-align:right;">P. Unitario</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($detalle['apus'] as $a): ?>
                <tr>
                    <td><?= htmlspecialchars((string)($a['item'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['codigo'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['descripcion'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['unidad'] ?? '')) ?></td>
                    <td style="text-align:right;"><?= number_format((float)($a['t_mat'] ?? 0), 2) ?></td>
                    <td style="text-align:right;"><?= number_format((float)($a['t_mo'] ?? 0), 2) ?></td>
                    <td style="text-align:right;"><?= number_format((float)($a['t_eq'] ?? 0), 2) ?></td>
                    <td style="text-align:right;"><strong><?= number_format((float)$a['precio_unitario'], 2) ?></strong></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($detalle['apus'])): ?><tr><td colspan="8" style="text-align:center;">Sin APUs.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- DETALLE DE LÍNEAS -->
    <h3>Detalle de cómputos</h3>
    <div class="table-wrap" style="overflow-x:auto;">
        <table>
            <thead><tr>
                <th>Item</th><th>Descripción</th><th>APU</th><th>Unidad</th>
                <th style="text-align:right;">N°</th><th style="text-align:right;">Factor</th>
                <th style="text-align:right;">L</th><th style="text-align:right;">A</th><th style="text-align:right;">H</th>
                <th style="text-align:right;">Parcial</th><th style="text-align:right;">P. Unit</th><th style="text-align:right;">Subtotal</th>
            </tr></thead>
                        <tbody>
            <?php foreach ($detalle['apus'] as $a): ?>
                <tr>
                    <td><?= htmlspecialchars((string)($a['item'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['codigo'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['descripcion'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($a['unidad'] ?? '')) ?></td>
                    <td style="text-align:right;"><?= number_format((float)($a['t_mat'] ?? 0), 2) ?></td>
                    <td style="text-align:right;"><?= number_format((float)($a['t_mo'] ?? 0), 2) ?></td>
                    <td style="text-align:right;"><?= number_format((float)($a['t_eq'] ?? 0), 2) ?></td>
                    <td style="text-align:right;"><strong><?= number_format((float)$a['precio_unitario'], 2) ?></strong></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($detalle['apus'])): ?><tr><td colspan="8" style="text-align:center;">Sin APUs.</td></tr><?php endif; ?>
            </tbody>>
            <tfoot><tr class="total"><th colspan="11" style="text-align:right;">TOTAL GENERAL</th><th style="text-align:right;"><?= number_format($detalle['computos_total'], 2) ?></th></tr></tfoot>
        </table>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>