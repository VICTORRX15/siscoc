<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Editar actividad — <?= htmlspecialchars($obra['nombre']) ?></h2>
    <p style="color:#64748b;margin-bottom:1rem;">
        Solo puedes modificar fechas y % de avance. La actividad se genera desde el cómputo asociado.
    </p>
    <form method="post" style="max-width:600px;background:#fff;padding:1.2rem;border-radius:10px;"
          action="<?= BASE_URL ?>?controller=cronograma&action=editar&id=<?= (int)$act['id'] ?>&obra_id=<?= (int)$obra['id'] ?>">
        <p><strong>Item:</strong> <?= htmlspecialchars($act['item'] ?? '') ?></p>
        <p><strong>Actividad:</strong> <?= htmlspecialchars($act['actividad']) ?></p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem;margin-top:1rem;">
            <label>Fecha inicio<br><input name="fecha_inicio" type="date" value="<?= htmlspecialchars($act['fecha_inicio']) ?>" required style="width:100%;padding:.5rem;"></label>
            <label>Fecha fin<br><input name="fecha_fin" type="date" value="<?= htmlspecialchars($act['fecha_fin']) ?>" required style="width:100%;padding:.5rem;"></label>
            <label>Avance (%)<br><input name="avance" type="number" min="0" max="100" value="<?= (int)$act['avance'] ?>" style="width:100%;padding:.5rem;"></label>
        </div>
        <p style="margin-top:1rem;">
            <button class="btn btn-primary" type="submit">Guardar</button>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=cronograma&action=index&obra_id=<?= (int)$obra['id'] ?>">Cancelar</a>
        </p>
    </form>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>