<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<?php
// Calcula rango global para el Gantt
$min = null; $max = null;
foreach ($actividades as $a) {
    if ($min === null || strtotime($a['fecha_inicio']) < $min) $min = strtotime($a['fecha_inicio']);
    if ($max === null || strtotime($a['fecha_fin'])    > $max) $max = strtotime($a['fecha_fin']);
}
$diasTotal = $min && $max ? max(1, (int)(($max - $min) / 86400) + 1) : 1;
?>
<div class="container">
    <h2>Cronograma (Gantt) — <?= htmlspecialchars($obra['nombre']) ?></h2>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;">
        <a class="btn btn-success" href="<?= BASE_URL ?>?controller=cronograma&action=exportar&obra_id=<?= (int)$obra['id'] ?>">📥 Exportar Excel</a>
        <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=ver&id=<?= (int)$obra['id'] ?>">← Volver</a>
    </div>

    <div class="table-wrap" style="overflow-x:auto;">
        <table>
            <thead><tr>
                <th>Item</th><th>Actividad</th><th>Inicio</th><th>Fin</th><th>Días</th><th>Avance</th><th>Gantt</th><th>Acciones</th>
            </tr></thead>
            <tbody>
            <?php foreach ($actividades as $a):
                $ini = strtotime($a['fecha_inicio']);
                $off = $min ? max(0, (int)(($ini - $min) / 86400)) : 0;
                $dur = max(1, (int)$a['duracion_dias']);
                $leftPct  = ($off / $diasTotal) * 100;
                $widthPct = ($dur / $diasTotal) * 100;
            ?>
                <tr>
                    <td><?= htmlspecialchars($a['item'] ?? '') ?></td>
                    <td><?= htmlspecialchars($a['actividad']) ?></td>
                    <td><?= htmlspecialchars($a['fecha_inicio']) ?></td>
                    <td><?= htmlspecialchars($a['fecha_fin']) ?></td>
                    <td><?= (int)$a['duracion_dias'] ?></td>
                    <td><?= (int)$a['avance'] ?>%</td>
                    <td style="min-width:200px;">
                        <div style="position:relative;background:#e2e8f0;height:18px;border-radius:4px;overflow:hidden;">
                            <div style="position:absolute;left:<?= $leftPct ?>%;width:<?= $widthPct ?>%;height:100%;background:#3b82f6;opacity:.85;"></div>
                            <div style="position:absolute;left:<?= $leftPct ?>%;width:<?= $widthPct * ((int)$a['avance'] / 100) ?>%;height:100%;background:#16a34a;"></div>
                        </div>
                    </td>
                    <td>
                        <a class="btn btn-outline" style="padding:.3rem .6rem;font-size:.85rem;"
                           href="<?= BASE_URL ?>?controller=cronograma&action=editar&id=<?= (int)$a['id'] ?>&obra_id=<?= (int)$obra['id'] ?>">Editar fechas/%</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($actividades)): ?>
                <tr><td colspan="8" style="text-align:center;">Sin actividades. Se crean al registrar cómputos.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>