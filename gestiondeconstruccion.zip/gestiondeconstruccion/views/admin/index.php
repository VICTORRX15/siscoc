<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Panel de Administración</h2>
    <p><a class="btn btn-primary" href="<?= BASE_URL ?>?controller=admin&action=crearToken">+ Crear token</a></p>

    <h3>Solicitudes pendientes</h3>
    <div class="table-wrap"><table>
        <tr><th>ID</th><th>Nombre</th><th>WhatsApp</th><th>Mensaje</th><th>Fecha</th><th>Acción</th></tr>
        <?php foreach ($solicitudes as $s): ?>
        <tr>
            <td><?= (int)$s['id'] ?></td>
            <td><?= htmlspecialchars($s['nombre']) ?></td>
            <td><?= htmlspecialchars($s['whatsapp']) ?></td>
            <td><?= htmlspecialchars($s['mensaje'] ?? '') ?></td>
            <td><?= htmlspecialchars($s['created_at']) ?></td>
            <td>
                <form method="POST" action="<?= BASE_URL ?>?controller=admin&action=crearToken" style="display:inline;">
                    <input type="hidden" name="nombre" value="<?= htmlspecialchars($s['nombre']) ?>">
                    <input type="hidden" name="whatsapp" value="<?= htmlspecialchars($s['whatsapp']) ?>">
                    <button class="btn btn-success" style="padding:.3rem .6rem;font-size:.85rem;">Aprobar + enviar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($solicitudes)): ?>
            <tr><td colspan="6" style="text-align:center;color:#64748b;">Sin solicitudes.</td></tr>
        <?php endif; ?>
    </table></div>

    <h3 style="margin-top:2rem;">Usuarios registrados</h3>
    <div class="table-wrap"><table>
        <tr><th>ID</th><th>Token</th><th>Nombre</th><th>WhatsApp</th><th>Rol</th><th>Activo</th><th>Último login</th></tr>
        <?php foreach ($users as $u): ?>
        <tr>
            <td><?= (int)$u['id'] ?></td>
            <td><code><?= htmlspecialchars($u['token']) ?></code></td>
            <td><?= htmlspecialchars($u['nombre'] ?? '') ?></td>
            <td><?= htmlspecialchars($u['whatsapp'] ?? '') ?></td>
            <td><?= htmlspecialchars($u['rol']) ?></td>
            <td><?= $u['activo'] ? '✅' : '❌' ?></td>
            <td><?= htmlspecialchars($u['last_login'] ?? '—') ?></td>
        </tr>
        <?php endforeach; ?>
    </table></div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>