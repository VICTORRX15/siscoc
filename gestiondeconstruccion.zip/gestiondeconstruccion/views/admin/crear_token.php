<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Crear token</h2>
    <form method="POST" class="auth-card" style="max-width:520px;margin:0 auto;">
        <label>Nombre</label>
        <input type="text" name="nombre" maxlength="100">
        <label>WhatsApp (con código país, sin +)</label>
        <input type="text" name="whatsapp" placeholder="59171234567" maxlength="20">
        <button class="btn btn-primary btn-block" style="margin-top:1rem;">Generar y enviar por WhatsApp</button>
    </form>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>