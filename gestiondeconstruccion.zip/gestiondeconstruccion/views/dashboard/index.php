<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Dashboard</h2>
    <?php if (Auth::esAdmin()): ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin:1rem 0;">
            <div class="login-card"><h3>Usuarios</h3><p style="font-size:1.6rem;font-weight:700;"><?= $stats['usuarios'] ?></p></div>
            <div class="login-card"><h3>Obras</h3><p style="font-size:1.6rem;font-weight:700;"><?= $stats['obras'] ?></p></div>
            <div class="login-card"><h3>APUs</h3><p style="font-size:1.6rem;font-weight:700;"><?= $stats['apus'] ?></p></div>
            <div class="login-card"><h3>Cómputos</h3><p style="font-size:1.6rem;font-weight:700;"><?= $stats['computos'] ?></p></div>
            <div class="login-card"><h3>Solicitudes pendientes</h3><p style="font-size:1.6rem;font-weight:700;"><?= $stats['solicitudes'] ?></p></div>
            <div class="login-card"><h3>Presupuesto total</h3><p style="font-size:1.6rem;font-weight:700;"><?= number_format($stats['presupuesto'],2) ?> Bs.</p></div>
        </div>
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
            <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=user&action=index">Gestionar usuarios</a>
            <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=token&action=index">Solicitudes token</a>
            <a class="btn btn-success" href="<?= BASE_URL ?>?controller=reporte&action=index">Reportes PDF</a>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=obra&action=index">Ver obras</a>
        </div>
    <?php else: ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin:1rem 0;">
            <div class="login-card"><h3>Mis obras</h3><p style="font-size:1.6rem;font-weight:700;"><?= $stats['obras'] ?></p></div>
            <div class="login-card"><h3>Presupuesto acumulado</h3><p style="font-size:1.6rem;font-weight:700;"><?= number_format($stats['presupuesto'],2) ?> Bs.</p></div>
        </div>
        <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=obra&action=index">Ir a mis obras</a>
    <?php endif; ?>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>