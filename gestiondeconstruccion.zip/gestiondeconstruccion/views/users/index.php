<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Usuarios</h2>
    <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=user&action=crear">+ Nuevo usuario</a>
    <div class="table-wrap" style="margin-top:1rem;overflow-x:auto;">
        <table>
            <thead><tr><th>ID</th><th>Token</th><th>Nombre</th><th>WhatsApp</th><th>Rol</th><th>Activo</th><th>Último login</th><th>Acciones</th></tr></thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= (int)$u['id'] ?></td>
                    <td style="font-family:monospace;"><?= htmlspecialchars((string)($u['token'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($u['nombre'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($u['whatsapp'] ?? '')) ?></td>
                    <td><?= htmlspecialchars((string)($u['rol'] ?? '')) ?></td>
                    <td><?= ((int)($u['activo'] ?? 0)) ? 'Sí' : 'No' ?></td>
                    <td><?= htmlspecialchars((string)($u['last_login'] ?? '—')) ?></td>
                    <td style="white-space:nowrap;">
                        <a class="btn btn-outline" style="padding:.3rem .6rem;font-size:.85rem;"
                           href="<?= BASE_URL ?>?controller=user&action=editar&id=<?= (int)$u['id'] ?>">Editar</a>
                        <?php if ((int)$u['id'] !== Auth::id()): ?>
                        <a class="btn btn-danger" style="padding:.3rem .6rem;font-size:.85rem;"
                           onclick="return confirm('¿Eliminar usuario?')"
                           href="<?= BASE_URL ?>?controller=user&action=eliminar&id=<?= (int)$u['id'] ?>">Borrar</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>