<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2><?= isset($user['id']) ? 'Editar' : 'Nuevo' ?> usuario</h2>
    <form method="post" style="max-width:600px;background:#fff;padding:1.2rem;border-radius:10px;"
          action="<?= BASE_URL ?>?controller=user&action=<?= isset($user['id']) ? 'editar&id='.(int)$user['id'] : 'crear' ?>">
        <label>Token (6 hex, vacío = genera automático)<br>
            <input name="token" maxlength="6" value="<?= htmlspecialchars($user['token'] ?? '') ?>"
                   style="width:100%;padding:.5rem;font-family:monospace;text-transform:uppercase;"></label>
        <label>Nombre<br>
            <input name="nombre" required value="<?= htmlspecialchars($user['nombre'] ?? '') ?>" style="width:100%;padding:.5rem;"></label>
        <label>WhatsApp<br>
            <input name="whatsapp" value="<?= htmlspecialchars($user['whatsapp'] ?? '') ?>" style="width:100%;padding:.5rem;"></label>
        <label>Rol<br>
            <select name="rol" style="width:100%;padding:.5rem;">
                <option value="usuario" <?= (($user['rol'] ?? 'usuario')==='usuario')?'selected':'' ?>>Usuario</option>
                <option value="admin"   <?= (($user['rol'] ?? '')==='admin')?'selected':'' ?>>Administrador</option>
            </select></label>
        <label>Activo<br>
            <select name="activo" style="width:100%;padding:.5rem;">
                <option value="1" <?= ((int)($user['activo'] ?? 1)===1)?'selected':'' ?>>Sí</option>
                <option value="0" <?= ((int)($user['activo'] ?? 1)===0)?'selected':'' ?>>No</option>
            </select></label>
        <p style="margin-top:1rem;">
            <button class="btn btn-primary" type="submit">Guardar</button>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=user&action=index">Cancelar</a>
        </p>
    </form>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>