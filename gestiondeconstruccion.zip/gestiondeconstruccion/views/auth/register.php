<?php $msg = rawurlencode('Hola, quiero registrarme en el sistema de gestión de construcción. Mi nombre es: '); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/app.css">
</head>
<body class="auth-body">
    <main class="auth-card">
        <h1>📝 Registrarse</h1>
        <p class="muted">El administrador te dará un token de 6 caracteres. Puedes solicitarlo así:</p>

        <form method="POST" action="<?= BASE_URL ?>?controller=auth&action=solicitar">
            <label>Nombre completo</label>
            <input type="text" name="nombre" required maxlength="100">
            <label>Tu WhatsApp</label>
            <input type="text" name="whatsapp" required maxlength="20" placeholder="59171234567">
            <label>Mensaje (opcional)</label>
            <input type="text" name="mensaje" maxlength="255">
            <button class="btn btn-primary btn-block" type="submit" style="margin-top:1rem;">Guardar solicitud</button>
        </form>

        <hr>
        <a class="btn btn-whatsapp btn-block"
           href="https://wa.me/<?= ADMIN_WHATSAPP ?>?text=<?= $msg ?>"
           target="_blank" rel="noopener">📱 Escribir al administrador</a>

        <p class="center" style="margin-top:1rem;">
            <a href="<?= BASE_URL ?>?controller=auth&action=login">← Volver al login</a>
        </p>
    </main>
</body>
</html>