<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión — SISCOC</title>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>css/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="login-brand">
        <img class="sistema"     src="<?= ASSETS_URL ?>img/logo_sistema.png"     alt="Sistema">
        <h1>Gestión de SISCOC</h1>
        <p>Sistema de control de obras, APUs, cómputos y presupuestos</p>
        <img class="institucion" src="<?= ASSETS_URL ?>img/logo_institucion.png" alt="Institución">
    </div>
    <div class="login-form">
        <div class="login-card">
            <h2>Iniciar sesión</h2>

            <?php if (!empty($error)): ?>
                <div class="err"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="post">
                <label>Token de acceso (6 caracteres)</label>

                <div class="input-token">
                    <input
                        type="password"
                        name="token"
                        id="token"
                        maxlength="6"
                        pattern="[0-9A-Fa-f]{6}"
                        required
                        placeholder="A1B2C3"
                        autocomplete="off"
                        autocapitalize="characters"
                        spellcheck="false"
                    >
                    <button
                        type="button"
                        class="toggle-token"
                        id="toggleToken"
                        aria-label="Mostrar token"
                        title="Mostrar token"
                    >
                        <svg id="eyeOpen" viewBox="0 0 24 24" width="20" height="20" fill="none"
                             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>
                        <svg id="eyeClosed" viewBox="0 0 24 24" width="20" height="20" fill="none"
                             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                             style="display:none;">
                            <path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94"/>
                            <path d="M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-3.16 4.19"/>
                            <line x1="1" y1="1" x2="23" y2="23"/>
                        </svg>
                    </button>
                </div>

                <button class="btn btn-primary" type="submit">Entrar</button>
            </form>

            <p class="help">
                ¿No tienes token? <a href="<?= BASE_URL ?>?controller=auth&action=solicitar">Solicítalo aquí</a>
            </p>
        </div>
    </div>
</div>

<script>
(function () {
    const input  = document.getElementById('token');
    const btn    = document.getElementById('toggleToken');
    const open   = document.getElementById('eyeOpen');
    const closed = document.getElementById('eyeClosed');

    btn.addEventListener('click', function () {
        const showing = input.type === 'text';
        input.type = showing ? 'password' : 'text';
        open.style.display   = showing ? 'block' : 'none';
        closed.style.display = showing ? 'none'  : 'block';
        btn.setAttribute('aria-label', showing ? 'Mostrar token' : 'Ocultar token');
        btn.setAttribute('title',      showing ? 'Mostrar token' : 'Ocultar token');
        input.focus();
    });

    input.addEventListener('input', function () {
        this.value = this.value.toUpperCase();
    });
})();
</script>
</body>
</html>