<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>Solicitar token</title>
<link rel="stylesheet" href="<?= ASSETS_URL ?>css/style.css"></head>
<body>
<div class="login-wrap">
    <div class="login-brand">
        <img class="sistema" src="<?= ASSETS_URL ?>img/logo_sistema.png" alt="">
        <h1>Solicitar token</h1>
    </div>
    <div class="login-form">
        <div class="login-card">
            <?php if (!empty($ok)): ?>
                <div style="color:#166534;background:#dcfce7;padding:.8rem;border-radius:8px;">
                    Solicitud enviada. Un administrador la revisará.
                </div>
                <p class="help"><a href="<?= BASE_URL ?>?controller=auth&action=login">Volver al login</a></p>
            <?php else: ?>
            <form method="post">
                <label>Nombre completo</label>
                <input name="nombre" required style="letter-spacing:normal;text-align:left;text-transform:none;font-size:1rem;">
                <label>WhatsApp</label>
                <input name="whatsapp" required style="letter-spacing:normal;text-align:left;text-transform:none;font-size:1rem;">
                <label>Motivo</label>
                <input name="motivo" style="letter-spacing:normal;text-align:left;text-transform:none;font-size:1rem;">
                <button class="btn btn-primary" type="submit">Enviar solicitud</button>
            </form>
            <p class="help"><a href="<?= BASE_URL ?>?controller=auth&action=login">Volver al login</a></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>