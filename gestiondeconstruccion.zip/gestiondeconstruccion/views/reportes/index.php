<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Reportes</h2>
    <p>Elige una obra para generar el reporte completo (APUs, cómputos, presupuesto y cronograma). Se abre en una pestaña lista para imprimir/guardar como PDF.</p>
    <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>Obra</th><th>Cliente</th><th>Presupuesto cómputos</th><th>Acción</th></tr></thead>
            <tbody>
            <?php foreach ($obras as $o): ?>
                <tr>
                    <td><?= (int)$o['id'] ?></td>
                    <td><?= htmlspecialchars($o['nombre']) ?></td>
                    <td><?= htmlspecialchars($o['cliente'] ?? '') ?></td>
                    <td><?= number_format((float)$o['total_computos'], 2) ?> Bs.</td>
                    <td>
                        <a class="btn btn-primary" target="_blank"
                           href="<?= BASE_URL ?>?controller=reporte&action=obra&id=<?= (int)$o['id'] ?>">Ver reporte</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>