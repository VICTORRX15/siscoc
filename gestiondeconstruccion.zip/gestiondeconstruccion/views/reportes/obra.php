<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reporte — <?= htmlspecialchars($obra['nombre']) ?></title>
<style>
    body { font-family: system-ui, sans-serif; margin: 2rem; color: #0f172a; }
    h1 { font-size: 1.4rem; margin-bottom: .2rem; }
    h2 { font-size: 1.1rem; margin-top: 1.5rem; border-bottom: 2px solid #0f172a; padding-bottom: .2rem; }
    table { width: 100%; border-collapse: collapse; margin-top: .5rem; font-size: .9rem; }
    th, td { border: 1px solid #cbd5e1; padding: .4rem .6rem; text-align: left; }
    th { background: #0f172a; color: #fff; }
    .num { text-align: right; }
    .total { font-weight: bold; background: #e2e8f0; }
    @media print { .no-print { display: none; } body { margin: 0; } }
</style>
</head>
<body>
<button class="no-print" onclick="window.print()" style="padding:.5rem 1rem;margin-bottom:1rem;cursor:pointer;">🖨️ Imprimir / Guardar PDF</button>

<h1><?= htmlspecialchars($obra['nombre']) ?></h1>
<p>Cliente: <?= htmlspecialchars($obra['cliente'] ?? '—') ?> | Ubicación: <?= htmlspecialchars($obra['ubicacion'] ?? '—') ?> | Estado: <?= htmlspecialchars($obra['estado']) ?></p>

<h2>APUs</h2>
<table>
    <thead><tr><th>Código</th><th>Descripción</th><th>Unidad</th><th>Materiales</th><th>M. Obra</th><th>Equipo</th><th>P. Unitario</th></tr></thead>
    <tbody>
    <?php foreach ($apus as $a): ?>
        <tr>
            <td><?= htmlspecialchars($a['codigo']) ?></td>
            <td><?= htmlspecialchars($a['descripcion']) ?></td>
            <td><?= htmlspecialchars($a['unidad']) ?></td>
            <td class="num"><?= number_format((float)$a['materiales'], 2) ?></td>
            <td class="num"><?= number_format((float)$a['mano_obra'], 2) ?></td>
            <td class="num"><?= number_format((float)$a['equipo'], 2) ?></td>
            <td class="num"><?= number_format((float)$a['precio_unitario'], 2) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<h2>Cómputos métricos</h2>
<table>
    <thead><tr><th>Item</th><th>Descripción</th><th>Unidad</th><th>N°</th><th>Factor</th><th>L</th><th>A</th><th>H</th><th>Parcial</th><th>P. Unit</th><th>Subtotal</th></tr></thead>
    <tbody>
    <?php $tot = 0; foreach ($computos as $c): $sub = (float)$c['cantidad']*(float)$c['precio_unitario']; $tot += $sub; ?>
        <tr>
            <td><?= htmlspecialchars($c['item'] ?? '') ?></td>
            <td><?= htmlspecialchars($c['descripcion']) ?></td>
            <td><?= htmlspecialchars($c['unidad']) ?></td>
            <td class="num"><?= number_format((float)$c['nro_veces'], 2) ?></td>
            <td class="num"><?= number_format((float)($c['factor_forma'] ?? 1), 3) ?></td>
            <td class="num"><?= number_format((float)$c['largo'], 3) ?></td>
            <td class="num"><?= number_format((float)$c['ancho'], 3) ?></td>
            <td class="num"><?= number_format((float)$c['alto'], 3) ?></td>
            <td class="num"><?= number_format((float)$c['cantidad'], 3) ?></td>
            <td class="num"><?= number_format((float)$c['precio_unitario'], 2) ?></td>
            <td class="num"><?= number_format($sub, 2) ?></td>
        </tr>
    <?php endforeach; ?>
        <tr class="total"><td colspan="10" class="num">TOTAL CÓMPUTOS</td><td class="num"><?= number_format($tot, 2) ?></td></tr>
    </tbody>
</table>

<h2>Presupuesto</h2>
<table>
    <tr><th>Límite</th><td class="num"><?= number_format((float)($presupuesto['limite'] ?? 0), 2) ?> Bs.</td></tr>
    <tr><th>Total cómputos</th><td class="num"><?= number_format((float)($presupuesto['computos_total'] ?? 0), 2) ?> Bs.</td></tr>
    <tr><th>Estado</th><td><?= (int)($presupuesto['excedido'] ?? 0) ? 'EXCEDIDO' : 'Dentro del límite' ?></td></tr>
</table>

<h2>Cronograma</h2>
<table>
    <thead><tr><th>Item</th><th>Actividad</th><th>Inicio</th><th>Fin</th><th>Días</th><th>Avance %</th></tr></thead>
    <tbody>
    <?php foreach ($cronograma as $a): ?>
        <tr>
            <td><?= htmlspecialchars($a['item'] ?? '') ?></td>
            <td><?= htmlspecialchars($a['actividad']) ?></td>
            <td><?= htmlspecialchars($a['fecha_inicio']) ?></td>
            <td><?= htmlspecialchars($a['fecha_fin']) ?></td>
            <td class="num"><?= (int)$a['duracion_dias'] ?></td>
            <td class="num"><?= (int)$a['avance'] ?>%</td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>