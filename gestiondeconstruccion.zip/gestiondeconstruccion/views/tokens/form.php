<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Nueva solicitud de token</h2>
    <form method="post" style="max-width:600px;background:#fff;padding:1.2rem;border-radius:10px;">
        <label>Nombre<br><input name="nombre" required style="width:100%;padding:.5rem;"></label>
        <label>WhatsApp<br><input name="whatsapp" required style="width:100%;padding:.5rem;"></label>
        <label>Motivo<br><input name="motivo" style="width:100%;padding:.5rem;"></label>
        <p style="margin-top:1rem;">
            <button class="btn btn-primary" type="submit">Guardar</button>
            <a class="btn btn-outline" href="<?= BASE_URL ?>?controller=token&action=index">Cancelar</a>
        </p>
    </form>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>