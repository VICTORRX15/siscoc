<?php require VIEWS_PATH . 'layouts/header.php'; ?>
<div class="container">
    <h2>Solicitudes de token</h2>
    <a class="btn btn-primary" href="<?= BASE_URL ?>?controller=token&action=crear">+ Nueva solicitud</a>
    <div class="table-wrap" style="margin-top:1rem;overflow-x:auto;">
        <table>
            <thead><tr><th>ID</th><th>Nombre</th><th>WhatsApp</th><th>Motivo</th><th>Estado</th><th>Token</th><th>Acciones</th></tr></thead>
            <tbody>
            <?php foreach ($solicitudes as $s): ?>
                <tr>
                    <td><?= (int)$s['id'] ?></td>
                    <td><?= htmlspecialchars($s['nombre']) ?></td>
                    <td><?= htmlspecialchars($s['whatsapp']) ?></td>
                    <td><?= htmlspecialchars($s['motivo'] ?? '') ?></td>
                    <td><?= htmlspecialchars($s['estado']) ?></td>
                    <td style="font-family:monospace;"><?= htmlspecialchars($s['token_generado'] ?? '') ?></td>
                    <td style="white-space:nowrap;">
                        <?php if ($s['estado'] === 'pendiente'): ?>
                            <a class="btn btn-success" style="padding:.3rem .6rem;font-size:.85rem;"
                               href="<?= BASE_URL ?>?controller=token&action=aprobar&id=<?= (int)$s['id'] ?>">Aprobar</a>
                            <a class="btn btn-outline" style="padding:.3rem .6rem;font-size:.85rem;"
                               href="<?= BASE_URL ?>?controller=token&action=rechazar&id=<?= (int)$s['id'] ?>">Rechazar</a>
                        <?php endif; ?>
                        <a class="btn btn-danger" style="padding:.3rem .6rem;font-size:.85rem;"
                           onclick="return confirm('¿Eliminar solicitud?')"
                           href="<?= BASE_URL ?>?controller=token&action=eliminar&id=<?= (int)$s['id'] ?>">Borrar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require VIEWS_PATH . 'layouts/footer.php'; ?>