<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
define('BASE_URL', $protocol . '://' . $host . $basePath . '/');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'construccion_db');

define('ADMIN_WHATSAPP', '5917117749'); // <-- TU NÚMERO AQUÍ

//
define('ROOT_PATH',      __DIR__ . '/../');
define('VIEWS_PATH',     ROOT_PATH . 'views/');
define('CONTROLLERS_PATH', ROOT_PATH . 'controllers/');
define('MODELS_PATH',    ROOT_PATH . 'models/');
define('HELPERS_PATH',   ROOT_PATH . 'helpers/');
define('CONFIG_PATH',    ROOT_PATH . 'config/');
define('ASSETS_URL', BASE_URL . 'assets/');
ini_set('display_errors', 1);
error_reporting(E_ALL);