<?php
class Excel {
    public static function download(string $filename, array $headers, array $rows): void {
        $filename = preg_replace('/[^A-Za-z0-9_\-]/', '_', $filename);
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"$filename.xls\"");
        header('Cache-Control: max-age=0');
        echo "\xEF\xBB\xBF";
        echo '<html><head><meta charset="UTF-8"></head><body><table border="1">';
        echo '<tr style="background:#1e293b;color:#fff;">';
        foreach ($headers as $h) echo '<th>' . htmlspecialchars($h) . '</th>';
        echo '</tr>';
        foreach ($rows as $r) {
            echo '<tr>';
            foreach ($r as $c) echo '<td>' . htmlspecialchars((string)$c) . '</td>';
            echo '</tr>';
        }
        echo '</table></body></html>';
        exit;
    }
}