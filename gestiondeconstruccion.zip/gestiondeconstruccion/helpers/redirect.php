<?php
function redirect(string $path): void {
    header('Location: ' . BASE_URL . $path);
    exit;
}