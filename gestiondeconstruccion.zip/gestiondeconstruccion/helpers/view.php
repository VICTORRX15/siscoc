<?php
function view(string $name, array $data = []): void {
    $file = VIEWS_PATH . $name . '.php';
    if (!file_exists($file)) {
        http_response_code(500);
        die("❌ Vista no encontrada: <code>" . htmlspecialchars($name) . "</code><br>
             Esperada en: <code>" . htmlspecialchars($file) . "</code>");
    }
    extract($data, EXTR_SKIP);
    require $file;
}