<?php
class Auth {
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    public static function login(string $token): bool {
        self::start();
        $db = Database::getConnection();
        $st = $db->prepare("SELECT * FROM users WHERE token=? AND activo=1");
        $st->execute([$token]);
        $u = $st->fetch();
        if (!$u) return false;

        $_SESSION['user_id']     = (int)$u['id'];
        $_SESSION['user_nombre'] = $u['nombre'];
        $_SESSION['user_rol']    = $u['rol'];
        $_SESSION['user_token']  = $u['token'];

        $db->prepare("UPDATE users SET last_login=NOW() WHERE id=?")->execute([$u['id']]);
        return true;
    }

    public static function logout(): void {
        self::start();
        session_destroy();
    }

    public static function check(): bool {
        self::start();
        return !empty($_SESSION['user_id']);
    }

    public static function id(): int {
        self::start();
        return (int)($_SESSION['user_id'] ?? 0);
    }

    public static function nombre(): string {
        self::start();
        return (string)($_SESSION['user_nombre'] ?? 'Invitado');
    }

    public static function rol(): string {
        self::start();
        return (string)($_SESSION['user_rol'] ?? 'usuario');
    }

    public static function esAdmin(): bool {
        return self::rol() === 'admin';
    }

    public static function requireLogin(): void {
        if (!self::check()) {
            header('Location: ' . BASE_URL . '?controller=auth&action=login');
            exit;
        }
    }

    public static function requireAdmin(): void {
        self::requireLogin();
        if (!self::esAdmin()) {
            http_response_code(403);
            die('Acceso solo para administradores.');
        }
    }

    public static function user(): ?array {
        if (!self::check()) return null;
        return [
            'id'     => self::id(),
            'nombre' => self::nombre(),
            'rol'    => self::rol(),
            'token'  => $_SESSION['user_token'] ?? '',
        ];
    }
}