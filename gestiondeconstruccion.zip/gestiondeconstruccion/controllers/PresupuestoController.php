<?php
require_once HELPERS_PATH . 'Auth.php';

class PresupuestoController {
    private Presupuesto $model;
    private Obra $obraModel;

    public function __construct() {
        Auth::requireLogin();
        $this->model     = new Presupuesto();
        $this->obraModel = new Obra();
    }

    public function index($obraId = null): void {
        $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
        $obra = $this->obraModel->find($obraId, Auth::id());
        if (!$obra) { http_response_code(404); die('Obra no encontrada'); }

        $this->model->recalcularPorObra($obraId);
        $presupuesto = $this->model->byObra($obraId);
        $detalle     = $this->model->detalleCompleto($obraId);
        require VIEWS_PATH . 'presupuestos/index.php';
    }

    public function exportar($obraId = null): void {
    $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
    $obra = $this->obraModel->find($obraId, Auth::id());
    if (!$obra) { http_response_code(404); die('Obra no encontrada'); }
    $detalle = $this->model->detalleCompleto($obraId);

    $filename = 'presupuesto_obra_' . $obraId . '_' . date('Ymd_His') . '.xls';
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo "\xEF\xBB\xBF"; // BOM para acentos

    echo '<html><head><meta charset="UTF-8"><style>
        table { border-collapse: collapse; font-family: Arial, sans-serif; font-size: 12px; }
        th, td { border: 1px solid #94a3b8; padding: 4px 8px; }
        th { background: #0f172a; color: #fff; }
        .sec { background: #1e3a8a; color: #fff; font-weight: bold; }
        .item { background: #dbeafe; font-weight: bold; }
        .num { text-align: right; }
        .total { background: #e2e8f0; font-weight: bold; }
        .excedido { color: #dc2626; font-weight: bold; }
        .ok { color: #16a34a; font-weight: bold; }
        .titulo { font-size: 16px; font-weight: bold; color: #0f172a; }
    </style></head><body>';

    // Cabecera
    echo '<p class="titulo">PRESUPUESTO DE OBRA</p>';
    echo '<table>';
    echo '<tr><th colspan="2">Datos de la obra</th></tr>';
    echo '<tr><td><strong>Obra</strong></td><td>' . htmlspecialchars($obra['nombre']) . '</td></tr>';
    echo '<tr><td><strong>Cliente</strong></td><td>' . htmlspecialchars((string)($obra['cliente'] ?? '—')) . '</td></tr>';
    echo '<tr><td><strong>Ubicación</strong></td><td>' . htmlspecialchars((string)($obra['ubicacion'] ?? '—')) . '</td></tr>';
    echo '<tr><td><strong>Estado</strong></td><td>' . htmlspecialchars($obra['estado']) . '</td></tr>';
    echo '<tr><td><strong>Fecha de reporte</strong></td><td>' . date('d/m/Y H:i') . '</td></tr>';
    echo '</table><br>';

    // Resumen
    echo '<p class="titulo">Resumen general</p>';
    echo '<table>';
    echo '<tr><th>Concepto</th><th>Valor (Bs.)</th></tr>';
    echo '<tr><td>Presupuesto límite</td><td class="num">' . number_format($detalle['limite'], 2) . '</td></tr>';
    echo '<tr><td>Total APUs (referencia)</td><td class="num">' . number_format($detalle['apus_total'], 2) . '</td></tr>';
    echo '<tr><td>Total cómputos métricos</td><td class="num">' . number_format($detalle['computos_total'], 2) . '</td></tr>';
    if ($detalle['limite'] > 0) {
        echo '<tr><td>Disponible</td><td class="num">' . number_format($detalle['disponible'], 2) . '</td></tr>';
    }
    echo '<tr><td>Avance ponderado</td><td class="num">' . $detalle['avance_pct'] . ' %</td></tr>';
    echo '<tr><td>Estado</td><td class="' . ($detalle['excedido'] ? 'excedido' : 'ok') . '">'
       . ($detalle['excedido'] ? 'EXCEDIDO' : ($detalle['limite'] > 0 ? 'Dentro del límite' : 'Sin límite'))
       . '</td></tr>';
    echo '</table><br>';

    // APUs
        // APUs
    echo '<p class="titulo">Detalle de APUs</p>';
    echo '<table><tr>'
       . '<th>Item</th><th>Código</th><th>Descripción</th><th>Unidad</th>'
       . '<th>Materiales</th><th>M. Obra</th><th>Equipo</th><th>P. Unitario</th></tr>';
    foreach ($detalle['apus'] as $a) {
        echo '<tr>'
            . '<td>' . htmlspecialchars((string)($a['item'] ?? '')) . '</td>'
            . '<td>' . htmlspecialchars((string)($a['codigo'] ?? '')) . '</td>'
            . '<td>' . htmlspecialchars((string)($a['descripcion'] ?? '')) . '</td>'
            . '<td>' . htmlspecialchars((string)($a['unidad'] ?? '')) . '</td>'
            . '<td class="num">' . number_format((float)($a['t_mat'] ?? 0), 2) . '</td>'
            . '<td class="num">' . number_format((float)($a['t_mo'] ?? 0), 2) . '</td>'
            . '<td class="num">' . number_format((float)($a['t_eq'] ?? 0), 2) . '</td>'
            . '<td class="num"><strong>' . number_format((float)($a['precio_unitario'] ?? 0), 2) . '</strong></td>'
            . '</tr>';
    }
    echo '</table><br>';

    // Cómputos por ítem con subtotales
    echo '<p class="titulo">Detalle de cómputos por ítem</p>';
    echo '<table><tr>'
       . '<th>Item</th><th>Descripción</th><th>Unidad</th><th>N°</th><th>Factor</th>'
       . '<th>L</th><th>A</th><th>H</th><th>Parcial</th><th>P. Unit</th><th>Subtotal</th></tr>';

    $itemActual = null; $totalItem = 0; $totalGeneral = 0;
    foreach ($detalle['lineas'] as $c) {
        $it = ($c['item'] ?? '') === '' ? '(sin item)' : $c['item'];
        if ($itemActual !== null && $it !== $itemActual) {
            echo '<tr class="item"><td colspan="10" class="num">TOTAL ÍTEM ' . htmlspecialchars($itemActual) . '</td>'
               . '<td class="num">' . number_format($totalItem, 2) . '</td></tr>';
            $totalItem = 0;
        }
        $itemActual = $it;
        $sub = (float)$c['cantidad'] * (float)$c['precio_unitario'];
        $totalItem += $sub;

        echo '<tr>'
            . '<td>' . htmlspecialchars($it) . '</td>'
            . '<td>' . htmlspecialchars((string)($c['descripcion'] ?? '')) . '</td>'
            . '<td>' . htmlspecialchars((string)($c['unidad'] ?? '')) . '</td>'
            . '<td class="num">' . number_format((float)$c['nro_veces'], 2) . '</td>'
            . '<td class="num">' . number_format((float)($c['factor_forma'] ?? 1), 3) . '</td>'
            . '<td class="num">' . number_format((float)$c['largo'], 3) . '</td>'
            . '<td class="num">' . number_format((float)$c['ancho'], 3) . '</td>'
            . '<td class="num">' . number_format((float)$c['alto'], 3) . '</td>'
            . '<td class="num">' . number_format((float)$c['cantidad'], 3) . '</td>'
            . '<td class="num">' . number_format((float)$c['precio_unitario'], 2) . '</td>'
            . '<td class="num">' . number_format($sub, 2) . '</td>'
            . '</tr>';
    }
    if ($itemActual !== null) {
        echo '<tr class="item"><td colspan="10" class="num">TOTAL ÍTEM ' . htmlspecialchars($itemActual) . '</td>'
           . '<td class="num">' . number_format($totalItem, 2) . '</td></tr>';
    }
    echo '<tr class="total"><td colspan="10" class="num">TOTAL GENERAL</td>'
       . '<td class="num">' . number_format($detalle['computos_total'], 2) . '</td></tr>';
    echo '</table></body></html>';
    exit;
}
}