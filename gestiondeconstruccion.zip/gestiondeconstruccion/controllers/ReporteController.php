<?php
require_once HELPERS_PATH . 'Auth.php';

class ReporteController {
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getConnection();
        $obras = $db->query(
            "SELECT o.*, COALESCE(p.computos_total,0) AS total_computos
             FROM obras o LEFT JOIN presupuestos p ON p.obra_id=o.id
             ORDER BY o.id DESC"
        )->fetchAll();
        require VIEWS_PATH . 'reportes/index.php';
    }

    public function obra($id = null): void {
        Auth::requireAdmin();
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $db = Database::getConnection();
        $st = $db->prepare("SELECT * FROM obras WHERE id=?"); $st->execute([$id]);
        $obra = $st->fetch();
        if (!$obra) { die('Obra no encontrada'); }

        $st = $db->prepare("SELECT * FROM computos WHERE obra_id=? ORDER BY item, id"); $st->execute([$id]);
        $computos = $st->fetchAll();
        $st = $db->prepare("SELECT * FROM apus WHERE obra_id=? ORDER BY id"); $st->execute([$id]);
        $apus = $st->fetchAll();
        $st = $db->prepare("SELECT * FROM cronograma WHERE obra_id=? ORDER BY fecha_inicio"); $st->execute([$id]);
        $cronograma = $st->fetchAll();
        $st = $db->prepare("SELECT * FROM presupuestos WHERE obra_id=?"); $st->execute([$id]);
        $presupuesto = $st->fetch();

        require VIEWS_PATH . 'reportes/obra.php';
    }
}