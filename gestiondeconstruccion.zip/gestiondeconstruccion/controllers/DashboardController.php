<?php
require_once HELPERS_PATH . 'Auth.php';

class DashboardController {
    public function index(): void {
        Auth::requireLogin();
        $db = Database::getConnection();
        if (Auth::esAdmin()) {
            $stats = [
                'usuarios'    => (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn(),
                'obras'       => (int)$db->query("SELECT COUNT(*) FROM obras")->fetchColumn(),
                'apus'        => (int)$db->query("SELECT COUNT(*) FROM apus")->fetchColumn(),
                'computos'    => (int)$db->query("SELECT COUNT(*) FROM computos")->fetchColumn(),
                'solicitudes' => (int)$db->query("SELECT COUNT(*) FROM token_solicitudes WHERE estado='pendiente'")->fetchColumn(),
                'presupuesto' => (float)$db->query("SELECT COALESCE(SUM(total),0) FROM presupuestos")->fetchColumn(),
            ];
        } else {
            $uid = Auth::id();
            $st = $db->prepare("SELECT COUNT(*) FROM obras WHERE user_id=?"); $st->execute([$uid]);
            $stats['obras'] = (int)$st->fetchColumn();
            $st = $db->prepare("SELECT COALESCE(SUM(p.total),0) FROM presupuestos p JOIN obras o ON o.id=p.obra_id WHERE o.user_id=?"); $st->execute([$uid]);
            $stats['presupuesto'] = (float)$st->fetchColumn();
            $stats = array_merge(['usuarios'=>0,'apus'=>0,'computos'=>0,'solicitudes'=>0], $stats);
        }
        require VIEWS_PATH . 'dashboard/index.php';
    }
}