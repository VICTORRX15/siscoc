<?php
require_once HELPERS_PATH . 'Auth.php';

class ApuController {
    private Apu $model;
    private Obra $obraModel;
    private Presupuesto $presu;

    public function __construct() {
        Auth::requireLogin();
        $this->model     = new Apu();
        $this->obraModel = new Obra();
        $this->presu     = new Presupuesto();
    }

    private function obra(int $obraId): array {
        $o = $this->obraModel->find($obraId, Auth::id());
        if (!$o) { http_response_code(404); die('Obra no encontrada'); }
        return $o;
    }

    public function index($obraId = null): void {
        $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
        $obra = $this->obra($obraId);
        $apus = $this->model->allByObra($obraId);
        require VIEWS_PATH . 'apus/index.php';
    }

    public function crear($obraId = null): void {
        $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
        $obra = $this->obra($obraId);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->create($obraId, $this->postData(), Auth::id());
            $this->presu->recalcularPorObra($obraId);
            header('Location: ' . BASE_URL . '?controller=apu&action=index&obra_id=' . $obraId); exit;
        }
        $apu = ['detalles' => []];
        require VIEWS_PATH . 'apus/form.php';
    }

    public function editar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obraId = (int)($_GET['obra_id'] ?? 0);
        $obra = $this->obra($obraId);
        $apu = $this->model->find($id, $obraId);
        if (!$apu) { http_response_code(404); die('APU no encontrado'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->update($id, $obraId, $this->postData());
            $this->presu->recalcularPorObra($obraId);
            header('Location: ' . BASE_URL . '?controller=apu&action=index&obra_id=' . $obraId); exit;
        }
        require VIEWS_PATH . 'apus/form.php';
    }

    public function eliminar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obraId = (int)($_GET['obra_id'] ?? 0);
        $this->obra($obraId);
        $this->model->delete($id, $obraId);
        $this->presu->recalcularPorObra($obraId);
        header('Location: ' . BASE_URL . '?controller=apu&action=index&obra_id=' . $obraId); exit;
    }

        private function postData(): array {
        $detalles = [];
        if (isset($_POST['tipo']) && is_array($_POST['tipo'])) {
            for ($i = 0; $i < count($_POST['tipo']); $i++) {
                if (empty($_POST['descripcion'][$i])) continue;
                $detalles[] = [
                    'tipo'            => $_POST['tipo'][$i],
                    'descripcion'     => trim($_POST['descripcion'][$i]),
                    'unidad'          => trim($_POST['unidad_item'][$i]),
                    'rendimiento'     => (float)$_POST['rendimiento'][$i],
                    'precio_unitario' => (float)$_POST['pu'][$i],
                ];
            }
        }

        return [
            'item'            => trim($_POST['apu_item'] ?? ''),          // 👈 Corregido
            'codigo'          => trim($_POST['codigo'] ?? ''),
            'descripcion'     => trim($_POST['apu_descripcion'] ?? ''),   // 👈 Corregido
            'unidad'          => trim($_POST['apu_unidad'] ?? ''),        // 👈 Corregido
            'precio_unitario' => (float)($_POST['precio_unitario'] ?? 0),
            'detalles'        => $detalles
        ];
    }
}