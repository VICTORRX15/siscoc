<?php
require_once HELPERS_PATH . 'Auth.php';

class ObraController {
    private Obra $model;
    private Presupuesto $presu;

    public function __construct() {
        Auth::requireLogin();
        $this->model = new Obra();
        $this->presu = new Presupuesto();
    }

    public function index(): void {
        $obras = $this->model->allByUser(Auth::id());
        require VIEWS_PATH . 'obras/index.php';
    }

    public function crear(): void {
        $obra = [];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre'] ?? '');
            if ($nombre === '') {
                $error = 'El nombre es obligatorio.';
                $obra = $_POST;
                require VIEWS_PATH . 'obras/form.php'; return;
            }
            $id = $this->model->create(Auth::id(), [
                'nombre'             => $nombre,
                'ubicacion'          => trim($_POST['ubicacion'] ?? ''),
                'cliente'            => trim($_POST['cliente'] ?? ''),
                'presupuesto'        => (float)($_POST['presupuesto'] ?? 0),
                'presupuesto_limite' => (float)($_POST['presupuesto_limite'] ?? 0),
                'estado'             => $_POST['estado'] ?? 'planificacion',
            ]);
            $this->presu->recalcularPorObra($id);
            header('Location: ' . BASE_URL . '?controller=obra&action=index'); exit;
        }
        require VIEWS_PATH . 'obras/form.php';
    }

    public function editar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obra = $this->model->find($id, Auth::id());
        if (!$obra) { http_response_code(404); die('Obra no encontrada'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre'] ?? '');
            if ($nombre === '') {
                $error = 'El nombre es obligatorio.';
                require VIEWS_PATH . 'obras/form.php'; return;
            }
            $this->model->update($id, Auth::id(), [
                'nombre'             => $nombre,
                'ubicacion'          => trim($_POST['ubicacion'] ?? ''),
                'cliente'            => trim($_POST['cliente'] ?? ''),
                'presupuesto'        => (float)($_POST['presupuesto'] ?? 0),
                'presupuesto_limite' => (float)($_POST['presupuesto_limite'] ?? 0),
                'estado'             => $_POST['estado'] ?? 'planificacion',
            ]);
            $this->presu->recalcularPorObra($id);
            header('Location: ' . BASE_URL . '?controller=obra&action=index'); exit;
        }
        require VIEWS_PATH . 'obras/form.php';
    }

    public function eliminar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obra = $this->model->find($id, Auth::id());
        if (!$obra) { http_response_code(404); die('Obra no encontrada'); }
        $this->model->delete($id, Auth::id());
        header('Location: ' . BASE_URL . '?controller=obra&action=index'); exit;
    }

    public function ver($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obra = $this->model->find($id, Auth::id());
        if (!$obra) { http_response_code(404); die('Obra no encontrada'); }
        require VIEWS_PATH . 'obras/ver.php';
    }
}