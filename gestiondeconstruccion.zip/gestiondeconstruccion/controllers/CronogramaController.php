<?php
require_once HELPERS_PATH . 'Auth.php';

class CronogramaController {
    private Cronograma $model;
    private Obra $obraModel;

    public function __construct() {
        Auth::requireLogin();
        $this->model     = new Cronograma();
        $this->obraModel = new Obra();
    }

    public function index($obraId = null): void {
        $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
        $obra = $this->obraModel->find($obraId, Auth::id());
        if (!$obra) { http_response_code(404); die('Obra no encontrada'); }

        $this->model->sincronizarObra($obraId);
        $actividades = $this->model->allByObra($obraId);
        require VIEWS_PATH . 'cronograma/index.php';
    }

    public function editar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obraId = (int)($_GET['obra_id'] ?? 0);
        $obra = $this->obraModel->find($obraId, Auth::id());
        if (!$obra) { http_response_code(404); die('Obra no encontrada'); }
        $act = $this->model->find($id, $obraId);
        if (!$act) { http_response_code(404); die('Actividad no encontrada'); }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->updateFechasAvance($id, $obraId, [
                'fecha_inicio' => $_POST['fecha_inicio'],
                'fecha_fin'    => $_POST['fecha_fin'],
                'avance'       => (int)$_POST['avance'],
            ]);
            header('Location: ' . BASE_URL . '?controller=cronograma&action=index&obra_id=' . $obraId); exit;
        }
        require VIEWS_PATH . 'cronograma/form.php';
    }

    public function exportar($obraId = null): void {
        $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
        $obra = $this->obraModel->find($obraId, Auth::id());
        if (!$obra) { http_response_code(404); die('Obra no encontrada'); }
        $acts = $this->model->allByObra($obraId);

        $filename = 'cronograma_obra_' . $obraId . '_' . date('Ymd_His') . '.xls';
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo "\xEF\xBB\xBF";
        echo '<html><head><meta charset="UTF-8"></head><body>';
        echo '<h2>Cronograma — ' . htmlspecialchars($obra['nombre']) . '</h2>';
        echo '<table border="1" cellpadding="4"><thead><tr style="background:#0f172a;color:#fff;">'
           . '<th>Item</th><th>Actividad</th><th>Inicio</th><th>Fin</th><th>Días</th><th>Avance %</th></tr></thead><tbody>';
        foreach ($acts as $a) {
            echo '<tr><td>' . htmlspecialchars($a['item'] ?? '') . '</td>'
               . '<td>' . htmlspecialchars($a['actividad']) . '</td>'
               . '<td>' . htmlspecialchars($a['fecha_inicio']) . '</td>'
               . '<td>' . htmlspecialchars($a['fecha_fin']) . '</td>'
               . '<td>' . (int)$a['duracion_dias'] . '</td>'
               . '<td>' . (int)$a['avance'] . '</td></tr>';
        }
        echo '</tbody></table></body></html>';
        exit;
    }
}