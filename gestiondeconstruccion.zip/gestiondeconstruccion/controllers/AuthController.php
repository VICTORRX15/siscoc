<?php
require_once HELPERS_PATH . 'Auth.php';

class AuthController {
    public function login(): void {
        if (Auth::check()) { header('Location: ' . BASE_URL . '?controller=dashboard&action=index'); exit; }
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = strtoupper(trim($_POST['token'] ?? ''));
            if (!preg_match('/^[0-9A-F]{6}$/', $token)) {
                $error = 'El token debe tener 6 caracteres hexadecimales (0-9, A-F).';
            } elseif (!Auth::login($token)) {
                $error = 'Token inválido o usuario inactivo.';
            } else {
                header('Location: ' . BASE_URL . '?controller=dashboard&action=index'); exit;
            }
        }
        require VIEWS_PATH . 'auth/login.php';
    }

    public function logout(): void {
        Auth::logout();
        header('Location: ' . BASE_URL . '?controller=auth&action=login'); exit;
    }

    public function solicitar(): void {
        $ok = false;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $m = new TokenSolicitud();
            $m->crear([
                'nombre'   => trim($_POST['nombre'] ?? ''),
                'whatsapp' => trim($_POST['whatsapp'] ?? ''),
                'motivo'   => trim($_POST['motivo'] ?? ''),
            ]);
            $ok = true;
        }
        require VIEWS_PATH . 'auth/solicitar.php';
    }
}