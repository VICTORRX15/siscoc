<?php
require_once HELPERS_PATH . 'Auth.php';

class TokenController {
    private TokenSolicitud $model;
    private User $userModel;
    public function __construct() {
        Auth::requireAdmin();
        $this->model = new TokenSolicitud();
        $this->userModel = new User();
    }

    public function index(): void {
        $solicitudes = $this->model->all();
        require VIEWS_PATH . 'tokens/index.php';
    }

    public function crear(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->crear([
                'nombre'   => trim($_POST['nombre'] ?? ''),
                'whatsapp' => trim($_POST['whatsapp'] ?? ''),
                'motivo'   => trim($_POST['motivo'] ?? ''),
            ]);
            header('Location: ' . BASE_URL . '?controller=token&action=index'); exit;
        }
        $sol = [];
        require VIEWS_PATH . 'tokens/form.php';
    }

    public function aprobar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $token = User::generarToken();
        $this->model->aprobar($id, $token, $this->userModel);
        header('Location: ' . BASE_URL . '?controller=token&action=index'); exit;
    }

    public function rechazar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $this->model->rechazar($id);
        header('Location: ' . BASE_URL . '?controller=token&action=index'); exit;
    }

    public function eliminar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $this->model->delete($id);
        header('Location: ' . BASE_URL . '?controller=token&action=index'); exit;
    }
}