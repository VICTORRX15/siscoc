<?php
require_once HELPERS_PATH . 'Auth.php';

class ComputoController {
    private Computo $model;
    private Obra $obraModel;
    private Apu $apuModel;
    private Presupuesto $presu;
    private Cronograma $cron;

    public function __construct() {
        Auth::requireLogin();
        $this->model     = new Computo();
        $this->obraModel = new Obra();
        $this->apuModel  = new Apu();
        $this->presu     = new Presupuesto();
        $this->cron      = new Cronograma();
    }

    private function obra(int $obraId): array {
        $o = $this->obraModel->find($obraId, Auth::id());
        if (!$o) { http_response_code(404); die('Obra no encontrada'); }
        return $o;
    }

    public function index($obraId = null): void {
    $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
    $obra = $this->obra($obraId);
    $computos      = $this->model->allByObra($obraId);
    $total         = $this->model->totalByObra($obraId);
    $totalesItem   = $this->model->totalesPorItem($obraId);
    $presupuesto   = $this->presu->byObra($obraId);
    require VIEWS_PATH . 'computos/index.php';
}

        public function crear($obraId = null): void {
        $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
        $obra = $this->obra($obraId);
        $apus = $this->apuModel->allByObra($obraId);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $d = $this->postData();
            $apu = $this->apuModel->find((int)$d['apu_id'], $obraId);
            if (!$apu) { $error = 'Debes seleccionar un APU válido.'; require VIEWS_PATH . 'computos/form.php'; return; }

            // Precio heredado del APU
            $d['precio_unitario'] = (float)$apu['precio_unitario'];
            
            // Calcular el subtotal sumando las cantidades de todas las líneas
            $cantidadTotal = 0;
            foreach ($d['detalles'] as $det) {
                $cantidadTotal += (float)$det['cantidad'];
            }
            $subtotal = $cantidadTotal * $d['precio_unitario'];

            // Verificar límite de presupuesto
            $check = $this->presu->puedeAgregar($obraId, $subtotal);
            if (!$check['ok']) {
                $error = 'Supera el límite de presupuesto de la obra (' . number_format($check['limite'], 2) . ' Bs.). Actual: ' . number_format($check['actual'], 2) . ' Bs. + Nuevo: ' . number_format($subtotal, 2) . ' Bs.';
                require VIEWS_PATH . 'computos/form.php'; return;
            }

            $id = $this->model->create($obraId, $d, Auth::id());
            $this->cron->asegurarDesdeComputo($id, $obraId);
            $this->presu->recalcularPorObra($obraId);
            header('Location: ' . BASE_URL . '?controller=computo&action=index&obra_id=' . $obraId); exit;
        }
        require VIEWS_PATH . 'computos/form.php';
    }

        public function editar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obraId = (int)($_GET['obra_id'] ?? 0);
        $obra = $this->obra($obraId);
        $computo = $this->model->find($id, $obraId);
        if (!$computo) { http_response_code(404); die('Cómputo no encontrado'); }
        $apus = $this->apuModel->allByObra($obraId);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $d = $this->postData();
            $apu = $this->apuModel->find((int)$d['apu_id'], $obraId);
            if (!$apu) { $error = 'Debes seleccionar un APU válido.'; require VIEWS_PATH . 'computos/form.php'; return; }
            $d['precio_unitario'] = (float)$apu['precio_unitario'];

            // Calcular el subtotal sumando las cantidades de las nuevas líneas
            $cantidadTotal = 0;
            foreach ($d['detalles'] as $det) {
                $cantidadTotal += (float)$det['cantidad'];
            }
            $subtotal = $cantidadTotal * $d['precio_unitario'];

            // Verificar límite de presupuesto excluyendo el valor actual de este cómputo
            $totalActualObra = $this->model->totalByObra($obraId);
            $resto = $totalActualObra - (float)$computo['parcial']; // Restamos el valor viejo
            
            $st = $this->obraModel->find($obraId, Auth::id());
            $limite = (float)($st['presupuesto_limite'] ?? 0);
            
            if ($limite > 0 && ($resto + $subtotal) > $limite + 0.001) {
                $error = 'La edición supera el límite de presupuesto (' . number_format($limite, 2) . ' Bs.).';
                require VIEWS_PATH . 'computos/form.php'; return;
            }

            $this->model->update($id, $obraId, $d);
            $this->cron->asegurarDesdeComputo($id, $obraId);
            $this->presu->recalcularPorObra($obraId);
            header('Location: ' . BASE_URL . '?controller=computo&action=index&obra_id=' . $obraId); exit;
        }
        require VIEWS_PATH . 'computos/form.php';
    }

    public function eliminar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $obraId = (int)($_GET['obra_id'] ?? 0);
        $this->obra($obraId);
        $this->model->delete($id, $obraId);
        $this->cron->eliminarPorComputo($id);
        $this->presu->recalcularPorObra($obraId);
        header('Location: ' . BASE_URL . '?controller=computo&action=index&obra_id=' . $obraId); exit;
    }

    public function exportar($obraId = null): void {
    $obraId = (int)($obraId ?? $_GET['obra_id'] ?? 0);
    $obra = $this->obra($obraId);
    $computos = $this->model->allByObra($obraId);
    $total = $this->model->totalByObra($obraId);

    $filename = 'computos_obra_' . $obraId . '_' . date('Ymd_His') . '.xls';
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo "\xEF\xBB\xBF";
    echo '<html><head><meta charset="UTF-8"></head><body>';
    echo '<h2>Cómputos Métricos — ' . htmlspecialchars($obra['nombre']) . '</h2>';
    echo '<table border="1" cellpadding="4"><thead><tr style="background:#0f172a;color:#fff;">'
       . '<th>Item</th><th>Descripción</th><th>Unidad</th><th>N°</th><th>Factor</th>'
       . '<th>L</th><th>A</th><th>H</th><th>Área</th><th>Volumen</th><th>Parcial</th>'
       . '<th>P. Unit</th><th>Subtotal</th><th>Observación</th></tr></thead><tbody>';

    $itemActual = null; $totalItem = 0;
    foreach ($computos as $c) {
        $it = ($c['item'] ?? '') === '' ? '(sin item)' : $c['item'];
        if ($itemActual !== null && $it !== $itemActual) {
            echo '<tr style="background:#e2e8f0;font-weight:bold;">'
               . '<td colspan="12" style="text-align:right;">TOTAL ÍTEM ' . htmlspecialchars($itemActual) . '</td>'
               . '<td>' . number_format($totalItem, 2) . '</td><td></td></tr>';
            $totalItem = 0;
        }
        $itemActual = $it;
        $sub = (float)$c['cantidad'] * (float)$c['precio_unitario'];
        $totalItem += $sub;

        echo '<tr>'
            . '<td>' . htmlspecialchars($it) . '</td>'
            . '<td>' . htmlspecialchars($c['descripcion']) . '</td>'
            . '<td>' . htmlspecialchars($c['unidad']) . '</td>'
            . '<td>' . number_format((float)$c['nro_veces'], 2) . '</td>'
            . '<td>' . number_format((float)($c['factor_forma'] ?? 1), 3) . '</td>'
            . '<td>' . number_format((float)$c['largo'], 3) . '</td>'
            . '<td>' . number_format((float)$c['ancho'], 3) . '</td>'
            . '<td>' . number_format((float)$c['alto'], 3) . '</td>'
            . '<td>' . number_format((float)($c['area'] ?? 0), 3) . '</td>'
            . '<td>' . number_format((float)($c['volumen'] ?? 0), 3) . '</td>'
            . '<td>' . number_format((float)$c['cantidad'], 3) . '</td>'
            . '<td>' . number_format((float)$c['precio_unitario'], 2) . '</td>'
            . '<td>' . number_format($sub, 2) . '</td>'
            . '<td>' . htmlspecialchars($c['observacion'] ?? '') . '</td></tr>';
    }
    if ($itemActual !== null) {
        echo '<tr style="background:#e2e8f0;font-weight:bold;">'
           . '<td colspan="12" style="text-align:right;">TOTAL ÍTEM ' . htmlspecialchars($itemActual) . '</td>'
           . '<td>' . number_format($totalItem, 2) . '</td><td></td></tr>';
    }
    echo '<tr style="background:#0f172a;color:#fff;font-weight:bold;">'
       . '<td colspan="12" style="text-align:right;">TOTAL GENERAL</td>'
       . '<td>' . number_format($total, 2) . '</td><td></td></tr>';
    echo '</tbody></table></body></html>';
    exit;
}   
     private function postData(): array {
        $detalles = [];
        
        if (isset($_POST['nro_veces']) && is_array($_POST['nro_veces'])) {
            for ($i = 0; $i < count($_POST['nro_veces']); $i++) {
                // Saltamos filas vacías
                if (empty($_POST['descripcion_linea'][$i]) && empty($_POST['largo'][$i]) && empty($_POST['ancho'][$i]) && empty($_POST['alto'][$i])) continue;
                
                $n = (float)($_POST['nro_veces'][$i] ?? 1);
                $f = (float)($_POST['factor_forma'][$i] ?? 1);
                $l = (float)($_POST['largo'][$i] ?? 0);
                $a = (float)($_POST['ancho'][$i] ?? 0);
                $h = (float)($_POST['alto'][$i] ?? 0);
                $tipo = $_POST['tipo_calculo'] ?? 'unidad'; // El tipo es global para todo el cómputo
                
                // Cálculo de la línea
                $area = $l * $a;
                $vol = $l * $a * $h;
                $base = 1;
                if ($tipo === 'area') $base = $area;
                if ($tipo === 'volumen') $base = $vol;
                if ($tipo === 'longitud') $base = $l;
                
                $cant = $base * $n * $f;

                $detalles[] = [
                    'descripcion_linea' => trim($_POST['descripcion_linea'][$i] ?? ''),
                    'nro_veces'       => $n,
                    'factor_forma'    => $f,
                    'largo'           => $l,
                    'ancho'           => $a,
                    'alto'            => $h,
                    'area'            => round($area, 3),
                    'volumen'         => round($vol, 3),
                    'cantidad'        => round($cant, 3)
                ];
            }
        }

        return [
            'apu_id'          => (int)($_POST['apu_id'] ?? 0),
            'item'            => trim($_POST['item'] ?? ''),
            'descripcion'     => trim($_POST['descripcion'] ?? ''),
            'tipo_calculo'    => $_POST['tipo_calculo'] ?? 'unidad',
            'unidad'          => trim($_POST['unidad'] ?? ''),
            'precio_unitario' => (float)($_POST['precio_unitario'] ?? 0),
            'observacion'     => trim($_POST['observacion'] ?? ''),
            'detalles'        => $detalles
        ];
    }
}