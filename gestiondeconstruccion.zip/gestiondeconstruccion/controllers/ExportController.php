<?php
require_once HELPERS_PATH . 'Auth.php';
require_once HELPERS_PATH . 'Excel.php';

class ExportController {
    public function computos(): void {
        Auth::requireLogin();

        $db = Database::getConnection();
        $stmt = $db->prepare(
            "SELECT c.id, o.nombre AS obra, c.descripcion, c.unidad,
                    c.cantidad, c.precio_unit, c.total
             FROM computos c
             INNER JOIN obras o ON o.id = c.obra_id AND o.user_id = c.user_id
             WHERE c.user_id = ?
             ORDER BY o.nombre, c.id"
        );
        $stmt->execute([Auth::id()]);
        $rows = $stmt->fetchAll();

        $headers = ['ID', 'Obra', 'Descripción', 'Unidad', 'Cantidad', 'Precio Unit.', 'Total'];
        $data = array_map(fn($r) => [
            $r['id'], $r['obra'], $r['descripcion'], $r['unidad'],
            (float)$r['cantidad'], (float)$r['precio_unit'], (float)$r['total']
        ], $rows);

        Excel::download('computos_' . date('Ymd_His'), $headers, $data);
    }

    public function obras(): void {
        Auth::requireLogin();
        $db = Database::getConnection();
        $stmt = $db->prepare("SELECT id, nombre, ubicacion, cliente, presupuesto, estado FROM obras WHERE user_id = ?");
        $stmt->execute([Auth::id()]);
        $rows = $stmt->fetchAll();

        Excel::download('obras_' . date('Ymd_His'),
            ['ID','Nombre','Ubicación','Cliente','Presupuesto','Estado'],
            array_map(fn($r) => array_values($r), $rows));
    }
}