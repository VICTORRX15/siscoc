<?php
require_once HELPERS_PATH . 'Auth.php';

class UserController {
    private User $model;
    public function __construct() {
        Auth::requireAdmin();
        $this->model = new User();
    }

    public function index(): void {
        $users = $this->model->all();
        require VIEWS_PATH . 'users/index.php';
    }

    public function crear(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->create([
                'token'    => strtoupper(trim($_POST['token'] ?? '')) ?: User::generarToken(),
                'nombre'   => trim($_POST['nombre'] ?? ''),
                'whatsapp' => trim($_POST['whatsapp'] ?? ''),
                'rol'      => $_POST['rol'] ?? 'usuario',
                'activo'   => (int)($_POST['activo'] ?? 1),
            ]);
            header('Location: ' . BASE_URL . '?controller=user&action=index'); exit;
        }
        $user = [];
        require VIEWS_PATH . 'users/form.php';
    }

    public function editar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        $user = $this->model->find($id);
        if (!$user) { http_response_code(404); die('Usuario no encontrado'); }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->update($id, [
                'token'    => strtoupper(trim($_POST['token'] ?? '')),
                'nombre'   => trim($_POST['nombre'] ?? ''),
                'whatsapp' => trim($_POST['whatsapp'] ?? ''),
                'rol'      => $_POST['rol'] ?? 'usuario',
                'activo'   => (int)($_POST['activo'] ?? 1),
            ]);
            header('Location: ' . BASE_URL . '?controller=user&action=index'); exit;
        }
        require VIEWS_PATH . 'users/form.php';
    }

    public function eliminar($id = null): void {
        $id = (int)($id ?? $_GET['id'] ?? 0);
        if ($id === Auth::id()) { die('No puedes eliminar tu propio usuario.'); }
        $this->model->delete($id);
        header('Location: ' . BASE_URL . '?controller=user&action=index'); exit;
    }
}