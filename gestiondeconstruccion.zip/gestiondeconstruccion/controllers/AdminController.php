<?php
require_once HELPERS_PATH . 'Auth.php';

class AdminController {
    private User $userModel;
    public function __construct() {
        Auth::requireLogin();
        $this->userModel = new User();
        if (!$this->userModel->isAdmin(Auth::id())) {
            http_response_code(403); die('Acceso solo para administradores.');
        }
    }

    public function index(): void {
        $db = Database::getConnection();
        $users = $db->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
        $solicitudes = $db->query("SELECT * FROM token_solicitudes WHERE estado='pendiente' ORDER BY id DESC")->fetchAll();
        require VIEWS_PATH . 'admin/index.php';
    }

    public function crearToken(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre'] ?? '');
            $wa     = trim($_POST['whatsapp'] ?? '');
            $token  = $this->userModel->generateUniqueToken();
            $this->userModel->create($token, $nombre ?: null, $wa ?: null, 'usuario');

            // Marca solicitud como aprobada si existe el whatsapp
            if ($wa !== '') {
                $db = Database::getConnection();
                $db->prepare("UPDATE token_solicitudes SET estado='aprobada' WHERE whatsapp = ? AND estado='pendiente'")
                   ->execute([$wa]);
            }

            // Redirige a WhatsApp con el token listo para enviar
            $msg = rawurlencode("Hola $nombre, tu token de acceso es: $token");
            header('Location: https://wa.me/' . preg_replace('/\D/', '', $wa) . '?text=' . $msg);
            exit;
        }
        require VIEWS_PATH . 'admin/crear_token.php';
    }
}