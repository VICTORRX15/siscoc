<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

spl_autoload_register(function ($class) {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $class)) return;
    foreach ([CONTROLLERS_PATH, MODELS_PATH, HELPERS_PATH] as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) { require_once $file; return; }
    }
});

require_once HELPERS_PATH . 'Auth.php';
Auth::start();

$controllerParam = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['controller'] ?? 'auth');
$actionParam     = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['action']     ?? (Auth::check() ? 'index' : 'login'));

$controllerName = ucfirst(strtolower($controllerParam)) . 'Controller';

// Si no está logueado, solo auth permite
if (!Auth::check() && $controllerName !== 'AuthController') {
    header('Location: ' . BASE_URL . '?controller=auth&action=login'); exit;
}
// Si está logueado y entra a auth/login sin cerrar sesión, redirige al dashboard
if (Auth::check() && $controllerName === 'AuthController' && $actionParam === 'login') {
    header('Location: ' . BASE_URL . '?controller=dashboard&action=index'); exit;
}

// Rutas restringidas a admin
$soloAdmin = ['UserController', 'TokenController', 'ReporteController'];
if (in_array($controllerName, $soloAdmin, true) && !Auth::esAdmin()) {
    http_response_code(403);
    die('Acceso solo para administradores.');
}

if (!class_exists($controllerName)) {
    http_response_code(404);
    die('Controlador no encontrado: ' . htmlspecialchars($controllerName));
}
$controller = new $controllerName();
if (!method_exists($controller, $actionParam)) {
    http_response_code(404);
    die('Acción no encontrada: ' . htmlspecialchars($actionParam));
}

$idParam = $_GET['id'] ?? null;
if ($idParam !== null && $idParam !== '') {
    $controller->$actionParam($idParam);
} else {
    $controller->$actionParam();
}