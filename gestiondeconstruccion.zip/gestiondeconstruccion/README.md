# 🏗️ Gestión de Construcción

Sistema PHP + MySQL multiusuario para gestión de obras, APUs y cómputos métricos.

## Requisitos
- PHP 7.4+ (recomendado 8.1+)
- MySQL 5.7+ / MariaDB 10.3+
- Apache con `mod_rewrite` habilitado (XAMPP/WAMP/Laragon)

## Instalación
1. Copia la carpeta a `htdocs/` (XAMPP) o `www/` (WAMP).
2. Importa `database/schema.sql` en phpMyAdmin.
3. Edita `config/config.php`:
   - `DB_NAME`, `DB_USER`, `DB_PASS`
   - `ADMIN_WHATSAPP` (tu número, sin `+`)
4. Abre `http://localhost/gestiondeconstruccion/`.
5. Login inicial: token `000001` (rol admin). **Cámbialo** luego.

## Roles
- **admin** (`000001`): puede crear tokens y aprobar solicitudes en
  `?controller=admin&action=index`.
- **usuario**: solo ve sus propias obras/APUs/cómputos (aislado por `user_id`).

## Seguridad
- Token hex de 6 caracteres validado por PHP + trigger MySQL.
- Triggers bloquean reasignación de `user_id` a otro usuario.
- Auditoría automática en `auditoria` para INSERT/UPDATE/DELETE.
- Todas las queries usan **PDO con prepared statements**.

## Exportación
- `?controller=export&action=computos` → `.xls` editable en Excel.
- `?controller=export&action=obras` → `.xls` editable.
- Para `.xlsx` real: `composer require phpoffice/phpspreadsheet` y usa
  `\PhpOffice\PhpSpreadsheet\Writer\Xlsx`.

## Estructura