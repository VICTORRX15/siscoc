<?php
class TokenSolicitud {
    private PDO $db;
    public function __construct() { $this->db = Database::getConnection(); }

    public function all(): array {
        return $this->db->query("SELECT * FROM token_solicitudes ORDER BY id DESC")->fetchAll();
    }

    public function find(int $id): ?array {
        $st = $this->db->prepare("SELECT * FROM token_solicitudes WHERE id=?");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    public function crear(array $d): int {
        $st = $this->db->prepare(
            "INSERT INTO token_solicitudes (nombre, whatsapp, motivo) VALUES (?,?,?)"
        );
        $st->execute([$d['nombre'], $d['whatsapp'], $d['motivo'] ?? '']);
        return (int)$this->db->lastInsertId();
    }

    public function aprobar(int $id, string $token, User $userModel): void {
        $sol = $this->find($id);
        if (!$sol) return;
        // Crea el usuario con ese token si no existe
        $db = Database::getConnection();
        $st = $db->prepare("SELECT id FROM users WHERE token=?");
        $st->execute([$token]);
        if (!$st->fetch()) {
            $userModel->create([
                'token'    => $token,
                'nombre'   => $sol['nombre'],
                'whatsapp' => $sol['whatsapp'],
                'rol'      => 'usuario',
                'activo'   => 1,
            ]);
        }
        $this->db->prepare(
            "UPDATE token_solicitudes SET estado='aprobada', token_generado=? WHERE id=?"
        )->execute([$token, $id]);
    }

    public function rechazar(int $id): void {
        $this->db->prepare("UPDATE token_solicitudes SET estado='rechazada' WHERE id=?")->execute([$id]);
    }

    public function delete(int $id): void {
        $this->db->prepare("DELETE FROM token_solicitudes WHERE id=?")->execute([$id]);
    }
}