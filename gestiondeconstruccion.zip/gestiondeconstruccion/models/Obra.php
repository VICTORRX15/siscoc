<?php
class Obra {
    private PDO $db;
    public function __construct() { $this->db = Database::getConnection(); }

    public function allByUser(int $userId): array {
        $st = $this->db->prepare("SELECT * FROM obras WHERE user_id=? ORDER BY id DESC");
        $st->execute([$userId]);
        return $st->fetchAll();
    }

    public function find(int $id, int $userId): ?array {
        $st = $this->db->prepare("SELECT * FROM obras WHERE id=? AND user_id=?");
        $st->execute([$id, $userId]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public function create(int $userId, array $d): int {
        $st = $this->db->prepare(
            "INSERT INTO obras (user_id, nombre, ubicacion, cliente, presupuesto, presupuesto_limite, estado)
             VALUES (?,?,?,?,?,?,?)"
        );
        $st->execute([
            $userId, $d['nombre'], $d['ubicacion'] ?? '', $d['cliente'] ?? '',
            (float)($d['presupuesto'] ?? 0),
            (float)($d['presupuesto_limite'] ?? 0),
            $d['estado'] ?? 'planificacion',
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, int $userId, array $d): void {
        $st = $this->db->prepare(
            "UPDATE obras SET nombre=?, ubicacion=?, cliente=?, presupuesto=?, presupuesto_limite=?, estado=?
             WHERE id=? AND user_id=?"
        );
        $st->execute([
            $d['nombre'], $d['ubicacion'] ?? '', $d['cliente'] ?? '',
            (float)($d['presupuesto'] ?? 0),
            (float)($d['presupuesto_limite'] ?? 0),
            $d['estado'] ?? 'planificacion',
            $id, $userId,
        ]);
    }

    public function delete(int $id, int $userId): void {
    // Verifica propiedad
    $st = $this->db->prepare("SELECT id FROM obras WHERE id=? AND user_id=?");
    $st->execute([$id, $userId]);
    if (!$st->fetch()) return;

    // Borrado en cascada manual (por si no hay FK con ON DELETE CASCADE)
    $this->db->prepare("DELETE FROM cronograma   WHERE obra_id=?")->execute([$id]);
    $this->db->prepare("DELETE FROM computos     WHERE obra_id=?")->execute([$id]);
    $this->db->prepare("DELETE FROM presupuestos WHERE obra_id=?")->execute([$id]);
    $this->db->prepare("DELETE FROM apus         WHERE obra_id=?")->execute([$id]);
    $this->db->prepare("DELETE FROM obras        WHERE id=? AND user_id=?")->execute([$id, $userId]);
}
}