<?php
class Apu {
    private PDO $db;

    public function __construct() { $this->db = Database::getConnection(); }

    public function allByObra(int $obraId): array {
        $st = $this->db->prepare("SELECT * FROM apus WHERE obra_id = ? ORDER BY item ASC, id ASC");
        $st->execute([$obraId]);
        return $st->fetchAll();
    }

    public function find(int $id, int $obraId): ?array {
        $st = $this->db->prepare("SELECT * FROM apus WHERE id = ? AND obra_id = ?");
        $st->execute([$id, $obraId]);
        $apu = $st->fetch();
        if (!$apu) return null;

        // Traer los insumos
        $stDet = $this->db->prepare("SELECT * FROM apu_detalles WHERE apu_id = ?");
        $stDet->execute([$id]);
        $apu['detalles'] = $stDet->fetchAll();
        return $apu;
    }

    public function create(int $obraId, array $d, int $userId): int {
        $precio = (float)$d['precio_unitario'];

        $st = $this->db->prepare("INSERT INTO apus (user_id, obra_id, item, codigo, descripcion, unidad, precio_unitario) VALUES (?,?,?,?,?,?,?)");
        $st->execute([$userId, $obraId, $d['item'], $d['codigo'], $d['descripcion'], $d['unidad'], $precio]);
        $apuId = (int)$this->db->lastInsertId();

        $this->guardarDetalles($apuId, $d['detalles'] ?? []);
        return $apuId;
    }

    public function update(int $id, int $obraId, array $d): void {
        $precio = (float)$d['precio_unitario'];
        $st = $this->db->prepare("UPDATE apus SET item=?, codigo=?, descripcion=?, unidad=?, precio_unitario=? WHERE id=? AND obra_id=?");
        $st->execute([$d['item'], $d['codigo'], $d['descripcion'], $d['unidad'], $precio, $id, $obraId]);

        // Borrar los detalles viejos e insertar los nuevos
        $this->db->prepare("DELETE FROM apu_detalles WHERE apu_id=?")->execute([$id]);
        $this->guardarDetalles($id, $d['detalles'] ?? []);
    }

    public function delete(int $id, int $obraId): void {
        // Al tener ON DELETE CASCADE en SQL, los detalles se borran solos
        $this->db->prepare("DELETE FROM apus WHERE id=? AND obra_id=?")->execute([$id, $obraId]);
    }

        private function guardarDetalles(int $apuId, array $detalles): void {
        $st = $this->db->prepare("INSERT INTO apu_detalles (apu_id, tipo, descripcion, unidad, rendimiento, precio_unitario, total) VALUES (?,?,?,?,?,?,?)");
        
        foreach ($detalles as $det) {
            if (trim($det['descripcion']) === '') continue;
            
            // Forzar que el tipo sea uno de los válidos y limpiar espacios
            $tipoLimpio = trim($det['tipo'] ?? 'materiales');
            if (!in_array($tipoLimpio, ['materiales', 'mano_obra', 'herramientas'])) {
                $tipoLimpio = 'materiales'; // Por defecto si llega algo raro
            }

            $rend = (float)$det['rendimiento'];
            $pu = (float)$det['precio_unitario'];
            $total = $rend * $pu;
            
            $st->execute([$apuId, $tipoLimpio, $det['descripcion'], $det['unidad'], $rend, $pu, $total]);
        }
    }
}