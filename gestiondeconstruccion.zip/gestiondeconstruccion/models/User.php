<?php
class User {
    private PDO $db;
    public function __construct() { $this->db = Database::getConnection(); }

    public function all(): array {
        return $this->db->query("SELECT * FROM users ORDER BY id ASC")->fetchAll();
    }

    public function find(int $id): ?array {
        $st = $this->db->prepare("SELECT * FROM users WHERE id=?");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    public function create(array $d): int {
        $st = $this->db->prepare(
            "INSERT INTO users (token, nombre, whatsapp, rol, activo) VALUES (?,?,?,?,?)"
        );
        $st->execute([
            $d['token'], $d['nombre'], $d['whatsapp'] ?? '',
            $d['rol'] ?? 'usuario', (int)($d['activo'] ?? 1),
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $d): void {
        $st = $this->db->prepare(
            "UPDATE users SET token=?, nombre=?, whatsapp=?, rol=?, activo=? WHERE id=?"
        );
        $st->execute([
            $d['token'], $d['nombre'], $d['whatsapp'] ?? '',
            $d['rol'] ?? 'usuario', (int)($d['activo'] ?? 1), $id,
        ]);
    }

    public function delete(int $id): void {
        $this->db->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
    }

    public static function generarToken(): string {
        return strtoupper(bin2hex(random_bytes(3))); // 6 hex chars
    }
}