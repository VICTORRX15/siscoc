<?php
class Computo {
    private PDO $db;

    public function __construct() { $this->db = Database::getConnection(); }

    public function allByObra(int $obraId): array {
        $st = $this->db->prepare("SELECT * FROM computos WHERE obra_id=? ORDER BY item ASC, id ASC");
        $st->execute([$obraId]);
        $computos = $st->fetchAll();

        // Traer las líneas de cada cómputo
        foreach ($computos as &$c) {
            $stD = $this->db->prepare("SELECT * FROM computo_detalles WHERE computo_id=?");
            $stD->execute([$c['id']]);
            $c['detalles'] = $stD->fetchAll();
        }
        return $computos;
    }

    public function find(int $id, int $obraId): ?array {
        $st = $this->db->prepare("SELECT * FROM computos WHERE id=? AND obra_id=?");
        $st->execute([$id, $obraId]);
        $c = $st->fetch();
        if (!$c) return null;

        $stD = $this->db->prepare("SELECT * FROM computo_detalles WHERE computo_id=?");
        $stD->execute([$id]);
        $c['detalles'] = $stD->fetchAll();
        return $c;
    }

    public function totalByObra(int $obraId): float {
        $st = $this->db->prepare("SELECT COALESCE(SUM(parcial),0) FROM computos WHERE obra_id=?");
        $st->execute([$obraId]);
        return (float)$st->fetchColumn();
    }

    /** Totales agrupados por item/sección */
    public function totalesPorItem(int $obraId): array {
        $st = $this->db->prepare(
            "SELECT item,
                    COUNT(*) AS lineas,
                    SUM(cantidad) AS cantidad,
                    SUM(parcial) AS total
             FROM computos
             WHERE obra_id=?
             GROUP BY item
             ORDER BY item ASC"
        );
        $st->execute([$obraId]);
        return $st->fetchAll();
    }

    public function create(int $obraId, array $d, int $userId): int {
        // 1. Calcular la cantidad total sumando todas las líneas
        $cantidadTotal = 0;
        foreach ($d['detalles'] as $lin) {
            $cantidadTotal += (float)$lin['cantidad'];
        }
        $parcial = $cantidadTotal * (float)$d['precio_unitario'];

        // 2. Guardar Cabecera
        $st = $this->db->prepare(
            "INSERT INTO computos (user_id, obra_id, apu_id, item, descripcion, unidad, cantidad, precio_unitario, parcial, observacion)
             VALUES (?,?,?,?,?,?,?,?,?,?)"
        );
        $st->execute([
            $userId, $obraId, $d['apu_id'] ?: null, $d['item'], $d['descripcion'], $d['unidad'],
            $cantidadTotal, (float)$d['precio_unitario'], $parcial, $d['observacion']
        ]);
        $computoId = (int)$this->db->lastInsertId();

        // 3. Guardar Líneas
        $this->guardarDetalles($computoId, $d['detalles']);
        return $computoId;
    }

    public function update(int $id, int $obraId, array $d): void {
        $cantidadTotal = 0;
        foreach ($d['detalles'] as $lin) {
            $cantidadTotal += (float)$lin['cantidad'];
        }
        $parcial = $cantidadTotal * (float)$d['precio_unitario'];

        // Actualizar Cabecera
        $st = $this->db->prepare(
            "UPDATE computos SET apu_id=?, item=?, descripcion=?, unidad=?, cantidad=?, precio_unitario=?, parcial=?, observacion=?
             WHERE id=? AND obra_id=?"
        );
        $st->execute([
            $d['apu_id'] ?: null, $d['item'], $d['descripcion'], $d['unidad'],
            $cantidadTotal, (float)$d['precio_unitario'], $parcial, $d['observacion'],
            $id, $obraId
        ]);

        // Borrar líneas viejas y guardar nuevas
        $this->db->prepare("DELETE FROM computo_detalles WHERE computo_id=?")->execute([$id]);
        $this->guardarDetalles($id, $d['detalles']);
    }

    public function delete(int $id, int $obraId): void {
        $this->db->prepare("DELETE FROM computo_detalles WHERE computo_id=?")->execute([$id]);
        $this->db->prepare("DELETE FROM computos WHERE id=? AND obra_id=?")->execute([$id, $obraId]);
    }

    private function guardarDetalles(int $computoId, array $detalles): void {
        $st = $this->db->prepare(
            "INSERT INTO computo_detalles (computo_id, descripcion_linea, nro_veces, factor_forma, largo, ancho, alto, area, volumen, cantidad)
             VALUES (?,?,?,?,?,?,?,?,?,?)"
        );
        foreach ($detalles as $lin) {
            $st->execute([
                $computoId, $lin['descripcion_linea'], $lin['nro_veces'], $lin['factor_forma'],
                $lin['largo'], $lin['ancho'], $lin['alto'], $lin['area'], $lin['volumen'], $lin['cantidad']
            ]);
        }
    }
}