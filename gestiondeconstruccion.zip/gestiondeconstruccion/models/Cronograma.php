<?php
class Cronograma {
    private PDO $db;

    public function __construct() { $this->db = Database::getConnection(); }

    public function allByObra(int $obraId): array {
        $st = $this->db->prepare("SELECT * FROM cronograma WHERE obra_id=? ORDER BY fecha_inicio ASC, id ASC");
        $st->execute([$obraId]);
        return $st->fetchAll();
    }

    public function find(int $id, int $obraId): ?array {
        $st = $this->db->prepare("SELECT * FROM cronograma WHERE id=? AND obra_id=?");
        $st->execute([$id, $obraId]);
        $r = $st->fetch();
        return $r ?: null;
    }

    /** Crea la fila de cronograma para un cómputo si no existe */
    public function asegurarDesdeComputo(int $computoId, int $obraId): void {
        $st = $this->db->prepare("SELECT * FROM cronograma WHERE computo_id=?");
        $st->execute([$computoId]);
        if ($st->fetch()) return;

        $st = $this->db->prepare("SELECT item, descripcion FROM computos WHERE id=?");
        $st->execute([$computoId]);
        $c = $st->fetch();
        if (!$c) return;

        $hoy = date('Y-m-d');
        $st = $this->db->prepare(
            "INSERT INTO cronograma (obra_id, computo_id, item, actividad, descripcion, fecha_inicio, fecha_fin, duracion_dias, avance)
             VALUES (?,?,?,?,?,?,?,?,0)"
        );
        $st->execute([
            $obraId, $computoId, $c['item'] ?? null,
            $c['descripcion'], $c['descripcion'],
            $hoy, $hoy, 1,
        ]);
    }

    /** Elimina la fila de cronograma asociada a un cómputo */
    public function eliminarPorComputo(int $computoId): void {
        $this->db->prepare("DELETE FROM cronograma WHERE computo_id=?")->execute([$computoId]);
    }

    /** Solo fechas y avance */
    public function updateFechasAvance(int $id, int $obraId, array $d): void {
        $ini = $d['fecha_inicio'];
        $fin = $d['fecha_fin'];
        $dur = max(1, (int)((strtotime($fin) - strtotime($ini)) / 86400) + 1);
        $av  = max(0, min(100, (int)$d['avance']));

        $st = $this->db->prepare(
            "UPDATE cronograma SET fecha_inicio=?, fecha_fin=?, duracion_dias=?, avance=? WHERE id=? AND obra_id=?"
        );
        $st->execute([$ini, $fin, $dur, $av, $id, $obraId]);
    }

    /** Recalcula todos los items de una obra (útil tras borrar cómputos) */
    public function sincronizarObra(int $obraId): void {
        $st = $this->db->prepare("SELECT id FROM computos WHERE obra_id=?");
        $st->execute([$obraId]);
        foreach ($st->fetchAll() as $c) {
            $this->asegurarDesdeComputo((int)$c['id'], $obraId);
        }
        // Borra cronogramas huérfanos
        $this->db->prepare(
            "DELETE cr FROM cronograma cr
             LEFT JOIN computos c ON c.id = cr.computo_id
             WHERE cr.obra_id=? AND (cr.computo_id IS NULL OR c.id IS NULL)"
        )->execute([$obraId]);
    }
}