<?php
class Presupuesto {
    private PDO $db;

    public function __construct() { $this->db = Database::getConnection(); }

    public function byObra(int $obraId): ?array {
        $st = $this->db->prepare("SELECT * FROM presupuestos WHERE obra_id=?");
        $st->execute([$obraId]);
        $r = $st->fetch();
        return $r ?: null;
    }
    
    public function recalcularPorObra(int $obraId): array {
        // Total de cómputos
        $st = $this->db->prepare("SELECT COALESCE(SUM(cantidad * precio_unitario),0) FROM computos WHERE obra_id=?");
        $st->execute([$obraId]);
        $computosTotal = (float)$st->fetchColumn();

        // Total de APUs (referencia)
        $st = $this->db->prepare("SELECT COALESCE(SUM(precio_unitario),0) FROM apus WHERE obra_id=?");
        $st->execute([$obraId]);
        $apusTotal = (float)$st->fetchColumn();

        // Límite de la obra
        $st = $this->db->prepare("SELECT presupuesto_limite FROM obras WHERE id=?");
        $st->execute([$obraId]);
        $limite = (float)($st->fetchColumn() ?: 0);

        $excedido = ($limite > 0 && $computosTotal > $limite + 0.001) ? 1 : 0;

        $row = $this->byObra($obraId);
        if ($row) {
            $st = $this->db->prepare(
                "UPDATE presupuestos SET total=?, computos_total=?, apus_total=?, limite=?, excedido=? WHERE obra_id=?"
            );
            $st->execute([$computosTotal, $computosTotal, $apusTotal, $limite, $excedido, $obraId]);
        } else {
            $st = $this->db->prepare(
                "INSERT INTO presupuestos (obra_id, nombre, total, computos_total, apus_total, limite, excedido)
                 VALUES (?,?,?,?,?,?,?)"
            );
            $st->execute([$obraId, 'Presupuesto automático', $computosTotal, $computosTotal, $apusTotal, $limite, $excedido]);
        }
        return $this->byObra($obraId) ?? [
            'computos_total' => $computosTotal,
            'apus_total'     => $apusTotal,
            'limite'         => $limite,
            'excedido'       => $excedido,
            'total'          => $computosTotal,
        ];
    }
    
    public function puedeAgregar(int $obraId, float $subtotalExtra): array {
        $st = $this->db->prepare("SELECT presupuesto_limite FROM obras WHERE id=?");
        $st->execute([$obraId]);
        $limite = (float)($st->fetchColumn() ?: 0);
        $actual = $this->totalComputos($obraId);
        if ($limite <= 0) return ['ok'=>true,'limite'=>0,'actual'=>$actual,'extra'=>$subtotalExtra];
        $nuevo = $actual + $subtotalExtra;
        return ['ok'=>$nuevo <= $limite + 0.001, 'limite'=>$limite, 'actual'=>$actual, 'extra'=>$subtotalExtra, 'nuevo'=>$nuevo];
    }

    private function totalComputos(int $obraId): float {
        $st = $this->db->prepare("SELECT COALESCE(SUM(cantidad * precio_unitario),0) FROM computos WHERE obra_id=?");
        $st->execute([$obraId]);
        return (float)$st->fetchColumn();
    }
        public function detalleCompleto(int $obraId): array {
        // APUs detallados con sus insumos sumados
                // APUs detallados con sus insumos sumados
        $st = $this->db->prepare(
            "SELECT a.*, 
                    (SELECT COALESCE(SUM(total),0) FROM apu_detalles d WHERE d.apu_id = a.id AND d.tipo = 'materiales') AS t_mat,
                    (SELECT COALESCE(SUM(total),0) FROM apu_detalles d WHERE d.apu_id = a.id AND d.tipo = 'mano_obra') AS t_mo,
                    (SELECT COALESCE(SUM(total),0) FROM apu_detalles d WHERE d.apu_id = a.id AND d.tipo = 'herramientas') AS t_eq
             FROM apus a
             WHERE a.obra_id=?
             ORDER BY a.item ASC, a.id ASC"
        );
        $st->execute([$obraId]);
        $apus = $st->fetchAll();

        $apusTotal = 0;
        foreach ($apus as $a) {
            $apusTotal += (float)$a['precio_unitario'];
        }

        // Cómputos agrupados por ítem
        $st = $this->db->prepare(
            "SELECT item,
                    COUNT(*) AS lineas,
                    SUM(cantidad) AS cantidad,
                    SUM(parcial) AS total
             FROM computos WHERE obra_id=? GROUP BY item ORDER BY item"
        );
        $st->execute([$obraId]);
        $porItem = $st->fetchAll();

        // Líneas de cómputo detalladas
        $st = $this->db->prepare(
            "SELECT c.*,
                    a.codigo      AS apu_codigo,
                    a.descripcion AS apu_descripcion,
                    a.unidad      AS apu_unidad
             FROM computos c
             LEFT JOIN apus a ON a.id = c.apu_id
             WHERE c.obra_id=?
             ORDER BY c.item, c.id"
        );
        $st->execute([$obraId]);
        $lineas = $st->fetchAll();

        // Cronograma
        $st = $this->db->prepare("SELECT * FROM cronograma WHERE obra_id=? ORDER BY fecha_inicio");
        $st->execute([$obraId]);
        $cronograma = $st->fetchAll();

        // Total general
        $st = $this->db->prepare("SELECT COALESCE(SUM(parcial),0) FROM computos WHERE obra_id=?");
        $st->execute([$obraId]);
        $computosTotal = (float)$st->fetchColumn();

        $st = $this->db->prepare("SELECT presupuesto_limite FROM obras WHERE id=?");
        $st->execute([$obraId]);
        $limite = (float)$st->fetchColumn();
                // Avance ponderado por presupuesto
        $avancePonderado = 0.0;
        if ($computosTotal > 0 && !empty($cronograma)) {
            $suma = 0.0;
            foreach ($cronograma as $cr) {
                // Peso = subtotal de las líneas de ese item
                $peso = 0.0;
                foreach ($lineas as $ln) {
                    if (($ln['item'] ?? '') === ($cr['item'] ?? '')) {
                        $peso += (float)$ln['parcial']; // Usamos la columna parcial que ya tiene el subtotal
                    }
                }
                $suma += $peso * ((int)$cr['avance'] / 100);
            }
            $avancePonderado = round(($suma / $computosTotal) * 100, 1);
        }
                return [
            'apus_total'      => $apusTotal,
            'computos_total'  => $computosTotal,
            'limite'          => $limite,
            'por_item'        => $porItem,
            'lineas'          => $lineas,
            'apus'            => $apus, 
            'cronograma'      => $cronograma,
            'avance_pct'      => $avancePonderado, 
            'excedido'        => ($limite > 0 && $computosTotal > $limite),
            'disponible'      => $limite > 0 ? max(0, $limite - $computosTotal) : null,
        ];
    }

}